# ESP32 BLE Follow-Car

An obstacle-avoiding vehicle that **follows the phone it is paired to**.
The phone connects over BLE; the car measures **distance** from the link
RSSI (log-distance path-loss model) and **direction** by swinging the
whole ESP32 board on an SG90 servo so the PCB antenna performs a radar
sweep — RSSI peaks when the antenna points at the phone. Two HC-SR04
sonars (front/rear) and an L298N dual H-bridge handle obstacle avoidance
and drive. Built for the **ESP32-S 30-pin DevKit (ESP-WROOM-32)** on
**ESP-IDF v5.5.x**.

Everything in this repository compiles clean (zero warnings) with
ESP-IDF v5.5.6 for the esp32 target. No stubs, no TODOs.

```
main/
├── main.c        boot order, task wiring, watchdog
├── nav.c         follow-mode state machine (SCAN→TURN→DRIVE→HOLD→AVOID)
├── ble_link.c    Bluedroid GATT server, secure pairing, RSSI polling
├── commands.c    command protocol (BLE + serial)
├── telemetry.c   compact telemetry frame
├── settings.c    NVS-persisted configuration
├── radar_math.c  RSSI filter, path-loss model, bearing estimator (host-tested)
├── sonar.c       dual HC-SR04, RMT hardware-timed
├── servo.c       SG90 driver, LEDC 14-bit, slew-limited
├── motor.c       L298N driver, LEDC 20 kHz, ramp/brake/trim
├── ui.c          status LED patterns + BOOT-button gestures
└── console.c     USB serial command line
tools/host_test_radar.c   gcc unit tests for radar_math
```

## How the tracking works (and what to expect)

* **Distance**: while the phone is connected, the ESP32 polls the link
  RSSI at 10 Hz, filters it (outlier gate → median-of-3 → EMA) and
  converts with `d = 10^((RSSI@1m − RSSI)/(10·n))`.
* **Bearing**: the servo swings the entire ESP32 board 0°→180°→0° in 6°
  steps (~2.7 s per sweep) while the car is stopped. RSSI samples are
  tagged with the servo angle; a 12-bin estimator (peak prominence +
  power-weighted centroid) returns the direction. A connected phone does
  not advertise, so link-RSSI modulation with antenna pointing is the
  only app-free direction cue — this is exactly why the servo carries
  the board instead of the sonars.
* **Accuracy, honestly**: expect ±10–20° bearing and ±20–40 % distance
  in a normal room. The state machine is built around this: measure →
  turn in place → drive straight in bursts → re-measure. It navigates
  like a cautious radar station, not like a missile.
* **Chase mode (optional, default ON)**: when not connected, the car
  scans for the *learned* phone address (stored on first connection)
  and can drive slowly toward its advertising packets so you can reach
  it and connect. iPhones rotate their addresses, so this works best on
  Android or immediately after a disconnect.

## Bill of materials

| Part | Qty | Notes |
|---|---|---|
| ESP32-S 30-pin DevKit (WROOM-32, CP2102) | 1 | mounted on the servo! |
| L298N red board | 1 | ENA/ENB jumpers removed |
| SG90 micro servo | 1 | carries the ESP32 board |
| HC-SR04 | 2 | front + rear on the chassis |
| 5 V buck ≥ 2 A (MP1584/LM2596/UBEC) | 1 | ESP32 + servo supply |
| Battery 2S LiPo / 6×AA / 3S 18650 pack | 1 | 7–12 V for L298N VIN |
| Resistors 2.2 kΩ + 3.3 kΩ | 2 pairs | echo level dividers |
| Capacitor 470–1000 µF on 5 V rail | 1 | absorbs servo stall spikes |

## Wiring

### L298N red board

| L298N | ESP32 | Meaning |
|---|---|---|
| ENA | D32 | LEFT PWM (jumper **removed**) |
| IN1 | D18 | LEFT direction A |
| IN2 | D19 | LEFT direction B |
| IN3 | D21 | RIGHT direction A |
| IN4 | D22 | RIGHT direction B |
| ENB | D33 | RIGHT PWM (jumper **removed**) |
| GND | GND | common ground (mandatory) |
| +12V / VIN | battery + | 7–12 V |
| OUT1/OUT2 | left motor(s) | 4WD: both left motors in parallel |
| OUT3/OUT4 | right motor(s) | 4WD: both right motors in parallel |

5 V regulator jumper (on the L298N): **keep ON only if** you use the
onboard 5 V for nothing but the L298N logic. ESP32 + servo must come
from the separate buck (see power notes) — the little 78M05 cannot
handle a stalling servo plus a radio.

### HC-SR04 ×2

| Sensor pin | ESP32 | Notes |
|---|---|---|
| FRONT VCC | 5 V | from buck |
| FRONT TRIG | D23 | 3.3 V trigger works on all HC-SR04 |
| FRONT ECHO | D34 | **via divider**: ECHO—2.2 kΩ—●—3.3 kΩ—GND, ●→D34 (≈3.0 V) |
| REAR VCC | 5 V | |
| REAR TRIG | D27 | |
| REAR ECHO | D35 | same divider |

GPIO34/35 are input-only — perfect for the divided echo signals.
Never connect a 5 V echo directly to an ESP32 pin.

### SG90 + ESP32

| Servo wire | Connect to |
|---|---|
| Orange (signal) | D13 |
| Red | 5 V from buck |
| Brown | GND (common) |

Mount the ESP32 on a small platform on the servo horn, antenna edge
facing outward, wires routed with a slack loop so they don't constrain
rotation. Unplug USB when the car runs on battery. Point the chassis
sonars slightly outward/down to avoid seeing the servo platform.

### Power

```
battery + ──┬── L298N VIN (+12V terminal) ── motors
            └── buck IN ── buck OUT 5 V ──┬── ESP32 VIN (5 V pin)
                                          ├── SG90 red
                                          └── HC-SR04 VCC ×2
battery − / L298N GND / buck GND / ESP32 GND / servo brown  →  common ground
```

Why: the SG90 stalls at ~650 mA and the ESP32 radio peaks ~300 mA — a
shared weak 5 V rail browns out the ESP32 mid-sweep. The 470–1000 µF
capacitor across the 5 V rail absorbs the servo's step load. The
brownout detector stays enabled as a last-resort safety net.

## Build & flash

```bash
# 1. Install ESP-IDF v5.5.x (https://docs.espressif.com/projects/esp-idf)
. $HOME/esp/esp-idf/export.sh
cd esp32-follow-car
idf.py set-target esp32
idf.py build
idf.py -p /dev/ttyUSB0 flash monitor      # Windows: COMx
```

Host-side unit tests (no hardware needed):

```bash
gcc -O2 -Wall -Wextra -I main tools/host_test_radar.c main/radar_math.c \
    -lm -o /tmp/host_test && /tmp/host_test
# === 24 passed, 0 failed ===
```

## First-run bring-up (do it in this order)

1. **Wheels up** (car on a box), battery connected, USB serial at
   115200. Expect the banner with name `ESP32-FollowCar`, passkey
   `246810`, then `L298N ready` / `sonar task running` / `BLE stack up`.
2. **Sonar check**: type `TEST SONAR`. Wave a hand in front of each
   sensor — front/rear values must move. A `sensor FAULT` log means
   wiring or divider problem.
3. **Servo check**: `SERVO 0`, `SERVO 90`, `SERVO 180`. Verify the board
   sweeps the full range. If an end strains, trim with
   `SET smin 700` / `SET smax 2300` (then `SAVE`).
4. **Motor direction**: `MODE MANUAL`, then `TEST M 40 40 800` — both
   sides must push **forward**. Fix any side with
   `SET invl 1` (left) / `SET invr 1`. `M F 40` / `M S` for raw checks.
5. **Straightness**: `TEST M 50 50 1500` — if the car curves,
   `SET triml 0.95` (or trimr 1.05, etc.).
6. **Pivot rate**: `TRN 90` — it should turn ≈90°. If it overshoots,
   raise `SET turnms 12` (ms per degree), if undershoots lower it.
7. **Distance calibration**: connect the phone (next section), hold the
   phone exactly **1 m** from the car, send `STAT` and read rssi, then
   `CAL DIST 1`. Repeat at 3 m with `CAL DIST 3` — if it reports ≈3 m
   you're done. Fine-tune environment with `SET pathn` (2.2 open room,
   2.6 default, 3.2 cluttered).
8. **Antenna calibration**: `SERVO 90` with the car nose pointing at
   you → if the board's antenna doesn't point exactly forward at 90°,
   physically note the angle that does, `SERVO <that angle>` then
   `CAL ANT`.
9. **First follow**: place phone 2–3 m ahead, `MODE FOLLOW`
   (or short-press BOOT), stand clear, and it should scan → turn →
   drive → stop at ~0.6 m. Tune `SET range 0.8` etc. to taste.

## Pairing & connecting

* The car advertises as **`ESP32-FollowCar`**, requires **LE Secure
  Connections with MITM + bonding**, static passkey **`246810`**
  (shown on serial at pairing time; change with `SET passkey 123456`
  + `SAVE`, takes effect after reboot).
* Open **nRF Connect** (Android/iOS) or **LightBlue**, scan, connect to
  `ESP32-FollowCar`, accept the pairing dialog, type the passkey.
  Characteristics appear after encryption:

| Name (UUID) | Props | Purpose |
|---|---|---|
| Command `f7a90002-6b8d-4c3e-a2f1-5d4b9c8e7a10` | write | send text commands |
| Telemetry `f7a90003-...` | read/notify | subscribe → 2 Hz status |
| Response `f7a90004-...` | read/notify | command replies |

* The **first** connecting phone's address is remembered as the target
  (survives reboots, powers chase mode). `UNPAIR` forgets it.
* Stale-bond trouble (phone stuck "pairing"): forget the device on the
  phone, and/or hold the BOOT button 5 s (`UNBOND` clears the car side).

## Command reference (BLE or serial)

```
HELP                        list commands
PING / VER / STAT           reachability / versions / full status
MODE <IDLE|FOLLOW|MANUAL>   navigation mode
ARM <ON|OFF>                FOLLOW only drives when armed
M <F|B|L|R|S> [pct]         manual drive (MANUAL only)
SERVO <0..180>              point the antenna
TRN <±deg>                  calibration pivot (+ = right)
TEST M <L%> <R%> <ms>       bounded motor test
TEST SONAR                  read both sonars once
SET <key> <value>           change setting (table below)
GET <key|ALL>               read settings
CAL DIST <m>                phone at known distance → rssi1m
CAL ANT                     current servo angle = straight ahead
SAVE                        persist settings
DEFAULTS                    factory reset settings
UNBOND / UNPAIR             clear bonds / forget target phone
```

Settings keys (`SET key value`): `name, passkey, rssi1m, pathn, antoff,
range (follow stop distance, m), maxspd, minspd, turnpct, turnms,
stopf (hard-stop cm), slowf, minduty, triml, trimr, invl, invr, unpair,
smin, smax, dbg`.

Telemetry frame (2 Hz notify):

```
T,<state>,<dist_m>,<rssi>,<bearing>,<conf>,<front_cm>,<rear_cm>,<servo>,<L%>,<R%>,<heap_kb>
   state: I idle | W wait-link | S scan | T turn | D drive | H hold
          A avoid | M manual | X test | E stop-wait        bearing=999 invalid
```

## Behavior & safety model

* **States**: `IDLE → WAIT_LINK → SCAN → TURN → DRIVE → HOLD`, with
  `AVOID` interleaved whenever the front sonar crosses the hard-stop
  threshold. Turning always invalidates the bearing (the antenna moved),
  so the car re-scans instead of steering on stale data.
* **Obstacles**: front < `slowf` scales speed down; front < `stopf`
  brakes, backs up if the rear is clear, pivots toward the phone's side,
  then re-scans. The rear sonar guards the backup. Two dead sonars cap
  speed and flag `E`/fast-blink.
* **Link loss**: connection drops → immediate stop → LED triple-flash →
  chase-mode search if enabled → permanent stop if nothing found. RSSI
  stale > 2 s while driving = same treatment. Driving blind is not an
  option in this firmware.
* **Watchdogs**: a monitor task kills the motors if the nav loop stalls
  3 s; motor duty is slew-limited; stops are true L298N brakes then
  coast.
* **Core pinning**: Bluedroid on core 0 (sdkconfig), nav + sonar + servo
  on core 1 → the 20 ms control loop and RMT echo timing never fight
  the Bluetooth stack.

## LED language

| Pattern | Meaning |
|---|---|
| solid | idle / manual (quiet) |
| 1 Hz blink | advertising, no phone |
| double-blink | connected, waiting for signal |
| heartbeat | connected and following |
| triple flash / 2 s | STOP_WAIT (searching / link lost) |
| very fast blink | fault (both sonars dead) |

**BOOT button**: short press = IDLE→FOLLOW(armed) → toggle armed /
MANUAL→IDLE; hold 5 s = clear all bonds.

## Troubleshooting

| Symptom | Cause / fix |
|---|---|
| ESP32 reboots when servo moves | 5 V rail sagging — use the buck + capacitor, never the L298N 5V-out for servo |
| Motor twitches at boot | normal one-time GPIO init glitch on some pins; wheels-up during boot |
| One side reversed | `SET invl 1` / `SET invr 1` |
| Car arcs while driving | `SET triml/trimr` |
| Bearing jumps around | metal/reflective room, board swinging into wires — check servo slack loop, raise `SET pathn`, keep phone line-of-sight |
| Distance wildly wrong | run `CAL DIST` at 1 m and 3 m; RSSI@1m differs per phone — calibrate with *your* phone |
| Pairing fails repeatedly | forget device on phone + `UNBOND`; then reconnect (fresh bond) |
| `sensor FAULT` but wired right | echo divider miswired (must be ~3.0 V at the GPIO), or 5 V pin dead |
| nRF Connect shows no characteristics | enable notifications after pairing; characteristics are encrypted — connect first, then refresh |

## Design facts (from the datasheets)

* **L298N** (ST L298 datasheet): logic inputs are TTL-compatible with
  VIH(min) = 2.3 V → ESP32 3.3 V drives IN1..IN4/ENA/ENB directly;
  drive voltage 5–35 V, 2 A per bridge (red board); both inputs equal +
  EN high = brake; EN low = coast. Onboard 8 flyback diodes cover
  recirculation.
* **HC-SR04**: 5 V supply, 10 µs trigger (12 µs used — also satisfies
  the 5 µs minimum of the "RAM" module variant), echo pulse ≈ 58 µs/cm
  round trip, range 2–400 cm, no-object = echo stays low (32 ms RX idle
  timeout used), measurement cycle ≥ 60 ms (this firmware pings each
  sensor ~12 Hz, alternating, so crosstalk is impossible).
* **SG90**: 50 Hz PWM, ~500–2400 µs for 180° (this firmware defaults to
  600–2400 µs and makes both endpoints tunable), 0.1 s/60° slew — the
  firmware's sweep rate (6°/90 ms ≈ 67°/s) stays far inside the
  mechanical limit even carrying the board, and LEDC 14-bit gives
  1.22 µs pulse resolution (< 1°/step).
