/*
 * radar_math.c - implementation of the pure-C radar DSP helpers.
 */
#include <math.h>
#include <string.h>

#include "radar_math.h"

float rm_clampf(float v, float lo, float hi)
{
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

float rm_median3f(float a, float b, float c)
{
    if (a > b) { float t = a; a = b; b = t; }
    if (b > c) { float t = b; b = c; c = t; }
    if (a > b) { float t = a; a = b; b = t; }
    return b;
}

void rm_rssi_filt_reset(rm_rssi_filt_t *f)
{
    if (!f) return;
    f->ema = 0.0f;
    f->n = 0;
    f->primed = false;
}

float rm_rssi_filt_update(rm_rssi_filt_t *f, int raw_rssi)
{
    if (!f) return -100.0f;

    float r = (float)raw_rssi;

    /* Physically impossible values -> keep previous estimate. */
    if (r >= 0.0f || r < -100.0f) {
        return f->primed ? f->ema : -100.0f;
    }

    /* Single-sample spike rejection: anything far from the running
     * estimate is almost certainly multipath/reflection noise. */
    if (f->primed && fabsf(r - f->ema) > RM_OUTLIER_DB) {
        return f->ema;
    }

    /* median-of-3 over the last accepted samples */
    f->win[f->n % 3] = r;
    f->n++;
    float med;
    if (f->n < 3) {
        med = r;
    } else {
        med = rm_median3f(f->win[0], f->win[1], f->win[2]);
    }

    if (!f->primed) {
        f->ema = med;
        f->primed = true;
    } else {
        f->ema = RM_EMA_ALPHA * med + (1.0f - RM_EMA_ALPHA) * f->ema;
    }
    return f->ema;
}

float rm_rssi_to_dist_m(int rssi, float rssi_at_1m, float path_n)
{
    if (rssi >= 0 || rssi < -100) return -1.0f;
    if (path_n < 1.5f) path_n = 1.5f;
    if (path_n > 4.5f) path_n = 4.5f;
    float exponent = (rssi_at_1m - (float)rssi) / (10.0f * path_n);
    float d = powf(10.0f, exponent);
    return rm_clampf(d, 0.15f, 25.0f);
}

/* internal: one pass of tri-1 smoothing over angle bins */
static void smooth_bins(float *b, int n)
{
    float out[12];
    for (int i = 0; i < n; i++) {
        float lo = b[i > 0 ? i - 1 : i];
        float hi = b[i < n - 1 ? i + 1 : i];
        out[i] = (lo + 2.0f * b[i] + hi) * 0.25f;
    }
    memcpy(b, out, sizeof(float) * (size_t)n);
}

void rm_solve_bearing(const rm_sweep_pt_t *pts, int n, rm_bearing_t *out)
{
    const int NB = 12;               /* 12 bins x 15 deg = 0..180 */
    const float BW = 180.0f / (float)NB;

    memset(out, 0, sizeof(*out));
    out->valid = false;
    out->conf = 0;
    out->bearing_deg = 90.0f;

    if (!pts || n < RM_MIN_SWEEP_PTS) return;

    float sum[12] = {0};
    int   cnt[12] = {0};

    for (int i = 0; i < n; i++) {
        float a = rm_clampf(pts[i].angle_deg, 0.0f, 180.0f);
        float r = rm_clampf(pts[i].rssi, -100.0f, 0.0f);
        int b = (int)(a / BW);
        if (b < 0) b = 0;
        if (b >= NB) b = NB - 1;
        sum[b] += r;
        cnt[b] += 1;
    }

    int nonempty = 0;
    for (int b = 0; b < NB; b++) {
        if (cnt[b] > 0) {
            sum[b] /= (float)cnt[b];
            nonempty++;
        }
    }
    /* Require coverage of at least 60% of the arc, otherwise the peak
     * could sit in an unswept gap. */
    if (nonempty < 7) return;

    /* Fill empty bins from nearest neighbours so the peak search and
     * smoothing see a continuous profile. */
    for (int b = 0; b < NB; b++) {
        if (cnt[b] == 0) {
            float lo = (b > 0) ? sum[b - 1] : sum[b + 1];
            float hi = (b < NB - 1) ? sum[b + 1] : sum[b - 1];
            sum[b] = (lo + hi) * 0.5f;
        }
    }

    smooth_bins(sum, NB);

    /* peak + median prominence */
    float peak = sum[0];
    for (int b = 1; b < NB; b++) {
        if (sum[b] > peak) peak = sum[b];
    }
    float sorted[12];
    memcpy(sorted, sum, sizeof(sorted));
    for (int i = 0; i < NB - 1; i++) {
        for (int j = i + 1; j < NB; j++) {
            if (sorted[j] < sorted[i]) { float t = sorted[i]; sorted[i] = sorted[j]; sorted[j] = t; }
        }
    }
    float median = (sorted[5] + sorted[6]) * 0.5f;
    float prom = peak - median;

    if (prom < RM_MIN_PROMINENCE || peak < RM_PEAK_MIN_RSSI) {
        out->peak_rssi = peak;
        out->prominence_db = prom;
        return;
    }

    /* Power-weighted centroid over the SMOOTHED BINS within 5 dB of the
     * peak. Bin averaging makes this robust to per-sample noise; the
     * weight mix of adjacent bins still yields continuous resolution. */
    float wsum = 0.0f, asum = 0.0f;
    for (int b = 0; b < NB; b++) {
        if (sum[b] >= peak - 5.0f) {
            float ang = ((float)b + 0.5f) * BW;
            float w = powf(10.0f, sum[b] / 10.0f);        /* linear power */
            asum += w * ang;
            wsum += w;
        }
    }
    if (wsum <= 0.0f) return;

    float coverage = (float)nonempty / (float)NB;
    float conf = rm_clampf((prom - 2.0f) * 20.0f, 0.0f, 60.0f) + coverage * 40.0f;

    out->valid = true;
    out->bearing_deg = rm_clampf(asum / wsum, 0.0f, 180.0f);
    out->peak_rssi = peak;
    out->prominence_db = prom;
    out->conf = (int)rm_clampf(conf, 0.0f, 100.0f);
}
