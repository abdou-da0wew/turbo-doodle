/*
 * telemetry.h - compact telemetry frame builder (BLE notify + STAT cmd).
 */
#pragma once
#include <stddef.h>

/* Builds "T,<st>,<dist_m>,<rssi>,<bearing>,<conf>,<front_cm>,<rear_cm>,
 *          <servo_deg>,<L%>,<R%>,<heap_kb>"
 * bearing = 999 when invalid. Fits comfortably in one BLE notification. */
void telemetry_build(char *buf, size_t cap);
