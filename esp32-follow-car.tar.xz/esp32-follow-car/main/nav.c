/*
 * nav.c - follow-mode state machine (runs on core 1, 20 ms tick).
 *
 * Cycle: SCAN (stop, sweep antenna, estimate bearing+distance) ->
 * TURN (in-place pivot toward bearing) -> DRIVE (straight burst with
 * obstacle-aware speed mixing) -> HOLD (arrived) ... repeat.
 *
 * Design notes
 *  - Turning invalidates the bearing (the antenna moved with the body),
 *    so every TURN ends back in SCAN. Bursts keep the loop tight.
 *  - The bearing comes from the CONNECTION RSSI (link) when paired;
 *    otherwise - if "unpaired follow" is on - from the advertising
 *    RSSI of the learned phone (chase mode, speed-capped).
 *  - Obstacles: front sonar scales speed, hard-stops into AVOID
 *    (backup if rear is clear, then pivot toward the phone side);
 *    rear sonar guards the backup itself.
 *  - Any link/estimator failure degrades to STOP: never to "keep
 *    driving blind".
 */
#include <math.h>
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "esp_timer.h"

#include "nav.h"
#include "settings.h"
#include "radar_math.h"
#include "servo.h"
#include "motor.h"
#include "sonar.h"
#include "ble_link.h"

static const char *TAG = "nav";

typedef enum {
    ST_IDLE, ST_WAIT_LINK, ST_SCAN, ST_TURN, ST_DRIVE,
    ST_HOLD, ST_AVOID, ST_MANUAL, ST_TEST, ST_STOP_WAIT,
} st_t;

/* ---- tuning constants (overridable via settings where noted) ---- */
#define NAV_TICK_MS          20
#define SCAN_STEP_DEG        6.0f
#define SCAN_STEP_MS         90
#define SCAN_SETTLE_MS       55
#define SCAN_PTS_MAX         40
#define TURN_TOL_DEG         10.0f
#define TURN_MIN_MS          150
#define TURN_MAX_MS          1200
#define DRIVE_BURST_MS       1600
#define LINK_STALE_US        2000000    /* 2 s */
#define ADV_STALE_US         3000000    /* 3 s */
#define BEARING_FRESH_US     1200000
#define PROBE_DEG            45.0f
#define PROBE_MAX_INVALID    6
#define BACKUP_MS            380
#define PIVOT_MS             450
#define BACKUP_PCT           35.0f
#define REAR_BLOCK_CM        20.0f
#define REAR_CLEAR_CM        35.0f
#define HOLD_HYST_M          0.25f
#define DIST_FRESH_GAIN      1.5f       /* m over which speed ramps */

static volatile st_t s_st = ST_IDLE;
static nav_mode_t s_mode = NAV_MODE_IDLE;
static bool s_armed = false;

/* manual inputs */
static float s_man_l, s_man_r;
static volatile float s_pending_turn_deg = 0.0f;
static volatile float s_pending_servo_deg = -1.0f;
static float s_test_l, s_test_r;
static int s_test_until;

/* scan machinery */
static rm_sweep_pt_t s_pts[SCAN_PTS_MAX];
static int s_pts_n;
static int s_scan_step;
static int s_scan_dir = 1;
static bool s_scan_from_left = true;
static int s_scan_next_ms;
static bool s_scan_sampled;
static int s_invalid_scans;
static int s_avoid_dir = 1;

/* shared results */
static float s_track_dist = -1.0f;
static int64_t s_track_ts = 0;
static bool s_track_is_link = false;
static float s_bearing_err = 0.0f;      /* vehicle-relative, +right */
static int s_bearing_conf = 0;
static bool s_bearing_valid = false;
static int64_t s_bearing_ts = 0;

static st_t s_turn_return = ST_IDLE;
static float s_turn_dur_ms = 0;
static int s_turn_end_ms;
static float s_turn_speed = 0;

static int s_avoid_phase;
static bool s_avoid_backup;
static int s_avoid_end_ms;

static settings_t s_cfg;                /* refreshed every tick */

static int now_ms(void)
{
    return (int)(xTaskGetTickCount() * portTICK_PERIOD_MS);
}

static void motors_zero(void)
{
    motor_set_lr(0, 0);
}

static void enter(st_t s)
{
    s_st = s;
}

/* ---------------- signal sources ---------------- */
static bool link_signal(float *dist_out, int *rssi_out)
{
    link_snap_t L;
    ble_link_get_snap(&L);
    if (L.connected && L.rssi_valid &&
        (esp_timer_get_time() - L.rssi_ts_us) < LINK_STALE_US) {
        *dist_out = L.dist_m;
        *rssi_out = L.rssi;
        return true;
    }
    return false;
}

static bool adv_signal(float *dist_out, int *rssi_out)
{
    link_snap_t L;
    ble_link_get_snap(&L);
    if (s_cfg.unpaired_follow && L.adv_valid &&
        (esp_timer_get_time() - L.adv_ts_us) < ADV_STALE_US) {
        *dist_out = L.adv_dist_m;
        *rssi_out = L.adv_rssi;
        return true;
    }
    return false;
}

static bool any_signal(float *dist_out, int *rssi_out, bool *is_link)
{
    if (link_signal(dist_out, rssi_out)) { *is_link = true; return true; }
    if (adv_signal(dist_out, rssi_out))  { *is_link = false; return true; }
    return false;
}

/* ---------------- SCAN ---------------- */
static void scan_begin(void)
{
    motors_zero();
    s_pts_n = 0;
    s_scan_step = 0;
    s_scan_sampled = false;
    s_scan_from_left = !s_scan_from_left;
    s_scan_dir = s_scan_from_left ? 1 : -1;
    float start = s_scan_from_left ? 0.0f : 180.0f;
    servo_set_target(start);
    s_scan_next_ms = now_ms() + SCAN_STEP_MS;
    enter(ST_SCAN);
    if (s_cfg.dbg) ESP_LOGI(TAG, "SCAN begin from %s", s_scan_from_left ? "left" : "right");
}

static void scan_finish(void)
{
    rm_bearing_t res;
    rm_solve_bearing(s_pts, s_pts_n, &res);

    float dist = -1.0f;
    int rssi = -100;
    bool sig = any_signal(&dist, &rssi, &s_track_is_link);
    if (sig) {
        s_track_dist = dist;
        s_track_ts = esp_timer_get_time();
    } else {
        s_track_dist = -1.0f;
    }

    servo_set_target(s_cfg.ant_off_deg);   /* park antenna forward */

    if (res.valid) {
        float err = res.bearing_deg - s_cfg.ant_off_deg;
        err = rm_clampf(err, -88.0f, 88.0f);
        s_bearing_err = err;
        s_bearing_conf = res.conf;
        s_bearing_valid = true;
        s_bearing_ts = esp_timer_get_time();
        s_invalid_scans = 0;
        if (s_cfg.dbg) {
            ESP_LOGI(TAG, "SCAN ok: brg=%.1f err=%.1f conf=%d peak=%.0f prom=%.1f pts=%d",
                     res.bearing_deg, err, res.conf, res.peak_rssi, res.prominence_db, s_pts_n);
        }
    } else {
        s_bearing_valid = false;
        s_invalid_scans++;
        if (s_cfg.dbg || s_invalid_scans >= 2) {
            ESP_LOGW(TAG, "SCAN inconclusive (pts=%d peak=%.0f prom=%.1f) #%d",
                     s_pts_n, res.peak_rssi, res.prominence_db, s_invalid_scans);
        }
    }

    /* ---- decision ---- */
    if (s_track_dist > 0 && s_track_dist <= s_cfg.hold_m) {
        motors_zero();
        enter(ST_HOLD);
        return;
    }
    if (s_bearing_valid && fabsf(s_bearing_err) > TURN_TOL_DEG) {
        s_turn_dur_ms = rm_clampf(fabsf(s_bearing_err) * s_cfg.turn_ms_per_deg,
                                  TURN_MIN_MS, TURN_MAX_MS);
        s_turn_end_ms = now_ms() + (int)s_turn_dur_ms;
        s_turn_speed = s_cfg.turn_pct;
        s_turn_return = ST_IDLE;         /* TURN decides next hop itself */
        enter(ST_TURN);
        return;
    }
    if (s_track_dist > 0) {
        s_turn_end_ms = now_ms() + DRIVE_BURST_MS;   /* burst timer */
        enter(ST_DRIVE);
        return;
    }
    /* nothing usable this scan */
    if (s_invalid_scans >= PROBE_MAX_INVALID) {
        ESP_LOGW(TAG, "giving up search -> STOP_WAIT");
        motors_zero();
        enter(ST_STOP_WAIT);
        return;
    }
    /* blind probe: alternate 45 deg pivots to re-find the peak */
    s_pending_turn_deg = (s_invalid_scans % 2 == 1) ? PROBE_DEG : -PROBE_DEG;
    s_turn_return = ST_SCAN;
    s_turn_dur_ms = rm_clampf(PROBE_DEG * s_cfg.turn_ms_per_deg, TURN_MIN_MS, TURN_MAX_MS);
    s_turn_end_ms = now_ms() + (int)s_turn_dur_ms;
    s_turn_speed = s_cfg.turn_pct;
    enter(ST_TURN);
}

static void scan_tick(void)
{
    int t = now_ms();
    if (t < s_scan_next_ms) return;
    s_scan_next_ms = t + SCAN_STEP_MS;

    if (!s_scan_sampled) {
        /* sample corresponds to the angle we just held */
        float dist = -1.0f;
        int rssi = -100;
        bool is_link;
        if (any_signal(&dist, &rssi, &is_link)) {
            link_snap_t L;
            ble_link_get_snap(&L);
            int64_t ts = is_link ? L.rssi_ts_us : L.adv_ts_us;
            bool fresh = (esp_timer_get_time() - ts) < 400000;
            if (fresh && s_pts_n < SCAN_PTS_MAX) {
                s_pts[s_pts_n].angle_deg = servo_get_angle();
                s_pts[s_pts_n].rssi = (float)rssi;
                s_pts_n++;
            }
        }
        s_scan_sampled = true;
        return;
    }

    /* advance to next sweep position */
    s_scan_step++;
    if (s_scan_step * SCAN_STEP_DEG > 180.0f) {
        scan_finish();
        return;
    }
    float target = s_scan_dir > 0 ? (s_scan_step * SCAN_STEP_DEG)
                                  : (180.0f - s_scan_step * SCAN_STEP_DEG);
    servo_set_target(target);
    s_scan_sampled = false;
}

/* ---------------- TURN ---------------- */
static void turn_tick(void)
{
    int t = now_ms();
    float err = s_bearing_valid ? s_bearing_err : 0.0f;
    float dir;
    if (s_pending_turn_deg != 0.0f) {
        dir = s_pending_turn_deg > 0 ? 1.0f : -1.0f;
    } else {
        dir = err > 0 ? 1.0f : -1.0f;    /* +err = phone on the right */
    }
    motor_set_lr(dir * s_turn_speed, -dir * s_turn_speed);

    sonar_snap_t S;
    sonar_get(&S);
    if (!S.front_fault && S.front_cm < s_cfg.stop_front_cm * 0.7f) {
        ESP_LOGW(TAG, "TURN aborted by front obstacle %.0fcm", S.front_cm);
        motors_zero();
        s_pending_turn_deg = 0;
        s_avoid_phase = 0;
        enter(ST_AVOID);
        return;
    }

    if (t >= s_turn_end_ms) {
        motors_zero();
        s_pending_turn_deg = 0;
        s_bearing_valid = false;         /* antenna moved -> stale */
        st_t ret = s_turn_return;
        s_turn_return = ST_IDLE;
        if (ret == ST_SCAN) { scan_begin(); return; }
        if (ret == ST_MANUAL) { enter(ST_MANUAL); return; }
        vTaskDelay(pdMS_TO_TICKS(120));  /* settle */
        enter(ST_SCAN);
        scan_begin();
    }
}

/* ---------------- DRIVE ---------------- */
static void drive_tick(void)
{
    /* signal still alive? */
    float dist = -1.0f;
    int rssi;
    bool is_link;
    if (!any_signal(&dist, &rssi, &is_link)) {
        ESP_LOGW(TAG, "DRIVE lost signal -> stop");
        motors_zero();
        enter(ST_STOP_WAIT);
        return;
    }
    s_track_dist = dist;
    s_track_ts = esp_timer_get_time();
    s_track_is_link = is_link;

    sonar_snap_t S;
    sonar_get(&S);

    /* obstacle speed mixing */
    float base = s_cfg.min_speed_pct +
                 (s_cfg.max_speed_pct - s_cfg.min_speed_pct) *
                 rm_clampf((dist - s_cfg.hold_m) / DIST_FRESH_GAIN, 0.0f, 1.0f);
    if (!is_link) base = rm_clampf(base, 0.0f, 35.0f);  /* chase mode cap */

    if (S.front_fault) {
        if (base > 30.0f) base = 30.0f;
    } else if (S.front_cm <= s_cfg.stop_front_cm) {
        motors_zero();
        s_avoid_phase = 0;
        enter(ST_AVOID);
        return;
    } else if (S.front_cm < s_cfg.slow_front_cm) {
        float f = (S.front_cm - s_cfg.stop_front_cm) /
                  (s_cfg.slow_front_cm - s_cfg.stop_front_cm);
        base *= rm_clampf(f, 0.30f, 1.0f);
    }

    /* gentle arc while the bearing is fresh */
    float arc = 0.0f;
    if (s_bearing_valid &&
        (esp_timer_get_time() - s_bearing_ts) < BEARING_FRESH_US &&
        fabsf(s_bearing_err) <= TURN_TOL_DEG) {
        arc = rm_clampf(s_bearing_err * 0.35f, -10.0f, 10.0f);
    }
    motor_set_lr(base + arc, base - arc);
    servo_set_target(s_cfg.ant_off_deg);

    if (dist <= s_cfg.hold_m + 0.02f) {
        motors_zero();
        enter(ST_HOLD);
        return;
    }
    if (now_ms() >= s_turn_end_ms) {
        scan_begin();                    /* refresh bearing regularly */
    }
}

/* ---------------- AVOID ---------------- */
static void avoid_tick(void)
{
    sonar_snap_t S;
    sonar_get(&S);
    int t = now_ms();

    switch (s_avoid_phase) {
    case 0:                               /* just braked */
        motors_zero();
        s_avoid_backup = S.rear_fault || S.rear_cm > REAR_CLEAR_CM;
        s_avoid_end_ms = t + 100;
        s_avoid_phase = 1;
        break;

    case 1:                               /* decide */
        if (t < s_avoid_end_ms) return;
        if (!S.rear_fault && S.rear_cm < REAR_CLEAR_CM) s_avoid_backup = false;
        if (s_avoid_backup) {
            s_avoid_end_ms = t + BACKUP_MS;
            s_avoid_phase = 2;
        } else {
            s_avoid_end_ms = t + PIVOT_MS;
            s_avoid_phase = 3;
        }
        break;

    case 2:                               /* back up slowly */
        motor_set_lr(-BACKUP_PCT, -BACKUP_PCT);
        if ((!S.rear_fault && S.rear_cm < REAR_BLOCK_CM) || t >= s_avoid_end_ms) {
            motors_zero();
            s_avoid_end_ms = t + PIVOT_MS;
            s_avoid_phase = 3;
        }
        break;

    case 3: {                             /* pivot toward target side */
        float dir = s_bearing_valid ? (s_bearing_err >= 0 ? 1.0f : -1.0f)
                                    : (s_avoid_dir > 0 ? 1.0f : -1.0f);
        motor_set_lr(dir * s_cfg.turn_pct, -dir * s_cfg.turn_pct);
        if (t >= s_avoid_end_ms) {
            motors_zero();
            if (!s_bearing_valid) s_avoid_dir = -s_avoid_dir;
            s_bearing_valid = false;
            s_avoid_phase = 0;
            ESP_LOGW(TAG, "AVOID done (backup=%d) -> rescan", s_avoid_backup ? 1 : 0);
            vTaskDelay(pdMS_TO_TICKS(120));
            scan_begin();
        }
        break;
    }

    default:
        s_avoid_phase = 0;
        break;
    }
}

/* ---------------- public manual/calibration inputs ---------------- */
void nav_manual_lr(float l_pct, float r_pct)
{
    s_man_l = rm_clampf(l_pct, -100.0f, 100.0f);
    s_man_r = rm_clampf(r_pct, -100.0f, 100.0f);
    if (s_mode == NAV_MODE_MANUAL && s_st != ST_TURN && s_st != ST_TEST) {
        s_st = ST_MANUAL;
    }
}

void nav_manual_turn(float deg)
{
    s_pending_turn_deg = rm_clampf(deg, -180.0f, 180.0f);
    s_turn_speed = s_cfg.turn_pct;
    if (s_mode == NAV_MODE_MANUAL) s_turn_return = ST_MANUAL;
    else s_turn_return = ST_IDLE;
    s_turn_dur_ms = rm_clampf(fabsf(s_pending_turn_deg) * s_cfg.turn_ms_per_deg,
                              TURN_MIN_MS, TURN_MAX_MS);
    s_turn_end_ms = now_ms() + (int)s_turn_dur_ms;
    s_st = ST_TURN;
}

void nav_manual_servo(float deg)
{
    s_pending_servo_deg = rm_clampf(deg, 0.0f, 180.0f);
}

void nav_test_motors(float l_pct, float r_pct, int ms)
{
    s_test_l = rm_clampf(l_pct, -60.0f, 60.0f);
    s_test_r = rm_clampf(r_pct, -60.0f, 60.0f);
    s_test_until = now_ms() + (ms > 0 && ms <= 2000 ? ms : 500);
    s_st = ST_TEST;
}

void nav_set_mode(nav_mode_t m)
{
    s_mode = m;
    s_invalid_scans = 0;
    s_bearing_valid = false;
    motors_zero();
    if (m == NAV_MODE_IDLE) s_st = ST_IDLE;
    else if (m == NAV_MODE_MANUAL) s_st = ST_MANUAL;
    else s_st = ST_WAIT_LINK;
    ESP_LOGI(TAG, "mode -> %s", m == NAV_MODE_FOLLOW ? "FOLLOW" :
                              m == NAV_MODE_MANUAL ? "MANUAL" : "IDLE");
}

nav_mode_t nav_mode(void) { return s_mode; }

void nav_set_armed(bool on)
{
    s_armed = on;
    if (!on && s_mode == NAV_MODE_FOLLOW) {
        motors_zero();
        s_st = ST_WAIT_LINK;
    }
    ESP_LOGW(TAG, "ARMED %s", on ? "ON" : "OFF");
}

bool nav_armed(void) { return s_armed; }

char nav_state_char(void)
{
    switch (s_st) {
    case ST_IDLE:      return 'I';
    case ST_WAIT_LINK: return 'W';
    case ST_SCAN:      return 'S';
    case ST_TURN:      return 'T';
    case ST_DRIVE:     return 'D';
    case ST_HOLD:      return 'H';
    case ST_AVOID:     return 'A';
    case ST_MANUAL:    return 'M';
    case ST_TEST:      return 'X';
    case ST_STOP_WAIT: return 'E';
    }
    return '?';
}

float nav_track_dist_m(void) { return s_track_dist; }

void nav_tlm_bearing(float *bearing_deg, int *conf)
{
    if (bearing_deg) *bearing_deg = s_bearing_valid ? s_bearing_err : 999.0f;
    if (conf) *conf = s_bearing_conf;
}

uint32_t nav_last_tick_ms(void)
{
    return (uint32_t)xTaskGetTickCount() * portTICK_PERIOD_MS;
}

/* ---------------- main task ---------------- */
void nav_task(void *pv)
{
    (void)pv;
    ESP_LOGI(TAG, "nav task on core %d, tick %d ms", xPortGetCoreID(), NAV_TICK_MS);

    TickType_t last = xTaskGetTickCount();
    while (1) {
        vTaskDelayUntil(&last, pdMS_TO_TICKS(NAV_TICK_MS));
        settings_get_copy(&s_cfg);

        /* one-shot servo command */
        if (s_pending_servo_deg >= 0) {
            servo_set_target(s_pending_servo_deg);
            s_pending_servo_deg = -1.0f;
        }

        servo_tick();
        motor_tick();

        switch (s_st) {
        case ST_IDLE:
            motors_zero();
            if (s_mode == NAV_MODE_FOLLOW && s_armed) enter(ST_WAIT_LINK);
            break;

        case ST_WAIT_LINK: {
            motors_zero();
            servo_set_target(s_cfg.ant_off_deg);
            float d;
            int r;
            bool is_link;
            if (s_mode == NAV_MODE_FOLLOW && s_armed &&
                any_signal(&d, &r, &is_link)) {
                scan_begin();
            }
            break;
        }

        case ST_SCAN:    scan_tick();  break;
        case ST_TURN:    turn_tick();  break;
        case ST_DRIVE:   drive_tick(); break;
        case ST_AVOID:   avoid_tick(); break;
        case ST_HOLD: {
            motors_zero();
            float d;
            int r;
            bool is_link;
            if (any_signal(&d, &r, &is_link)) {
                if (d > s_cfg.hold_m + HOLD_HYST_M) scan_begin();
            } else if ((esp_timer_get_time() - s_track_ts) > 4000000) {
                enter(ST_STOP_WAIT);
            }
            break;
        }

        case ST_MANUAL:
            if (s_mode != NAV_MODE_MANUAL) { motors_zero(); enter(ST_IDLE); break; }
            motor_set_lr(s_man_l, s_man_r);
            break;

        case ST_TEST:
            motor_set_lr(s_test_l, s_test_r);
            if (now_ms() >= s_test_until) {
                motors_zero();
                s_st = (s_mode == NAV_MODE_MANUAL) ? ST_MANUAL : ST_IDLE;
            }
            break;

        case ST_STOP_WAIT:
            motors_zero();
            {
                float d;
                int r;
                bool is_link;
                if (s_mode == NAV_MODE_FOLLOW && s_armed &&
                    any_signal(&d, &r, &is_link)) {
                    ESP_LOGI(TAG, "signal back -> rescanning");
                    s_invalid_scans = 0;
                    scan_begin();
                }
            }
            break;
        }
    }
}
