/*
 * settings.c - NVS-backed configuration store.
 */
#include <math.h>
#include <stdio.h>
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "nvs_flash.h"
#include "nvs.h"
#include "esp_log.h"

#include "settings.h"

static const char *TAG = "settings";

#define NS        "fcar"
#define BLOB_KEY  "cfg"
#define MAGIC     0x46434152u   /* "FCAR" */

static settings_t s_cfg;
static SemaphoreHandle_t s_lock;
static const settings_t *s_defaults;

static const settings_t k_defaults = {
    .name            = "ESP32-FollowCar",
    .passkey         = 246810,
    .rssi_1m         = -59.0f,
    .path_n          = 2.6f,
    .ant_off_deg     = 90.0f,
    .hold_m          = 0.6f,
    .max_speed_pct   = 55.0f,
    .min_speed_pct   = 18.0f,
    .turn_pct        = 45.0f,
    .turn_ms_per_deg = 9.5f,
    .stop_front_cm   = 26.0f,
    .slow_front_cm   = 70.0f,
    .minduty_pct     = 22.0f,
    .trim_l          = 1.0f,
    .trim_r          = 1.0f,
    .invert_l        = 0,
    .invert_r        = 0,
    .unpaired_follow = 1,
    .servo_min_us    = 600,
    .servo_max_us    = 2400,
    .dbg             = 0,
};

void settings_init(void)
{
    s_defaults = &k_defaults;
    s_cfg = k_defaults;
    s_lock = xSemaphoreCreateMutex();

    nvs_handle_t h;
    esp_err_t err = nvs_open(NS, NVS_READONLY, &h);
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "no stored settings (%s), using defaults", esp_err_to_name(err));
        return;
    }
    settings_t tmp;
    size_t len = sizeof(tmp);
    err = nvs_get_blob(h, BLOB_KEY, &tmp, &len);
    nvs_close(h);
    if (err == ESP_OK && len == sizeof(tmp) && tmp.passkey != 0xFFFFFFFFu &&
        tmp.rssi_1m > -100.0f && tmp.rssi_1m < 0.0f) {
        tmp.name[SETTINGS_NAME_MAX - 1] = '\0';
        s_cfg = tmp;
        ESP_LOGI(TAG, "settings loaded: name='%s' passkey=%" PRIu32, s_cfg.name, s_cfg.passkey);
    } else {
        ESP_LOGW(TAG, "stored settings invalid (%s), defaults in use", esp_err_to_name(err));
    }
}

void settings_get_copy(settings_t *out)
{
    if (!out) return;
    if (xSemaphoreTake(s_lock, pdMS_TO_TICKS(50)) == pdTRUE) {
        *out = s_cfg;
        xSemaphoreGive(s_lock);
    } else {
        *out = k_defaults;   /* never block the control loop on config */
    }
}

static settings_t *lock_mut(void)
{
    xSemaphoreTake(s_lock, portMAX_DELAY);
    return &s_cfg;
}

static void unlock_mut(void)
{
    xSemaphoreGive(s_lock);
}

void settings_save(void)
{
    settings_t snap;
    settings_get_copy(&snap);
    nvs_handle_t h;
    if (nvs_open(NS, NVS_READWRITE, &h) != ESP_OK) {
        ESP_LOGE(TAG, "NVS open failed for save");
        return;
    }
    esp_err_t err = nvs_set_blob(h, BLOB_KEY, &snap, sizeof(snap));
    if (err == ESP_OK) err = nvs_commit(h);
    nvs_close(h);
    ESP_LOGI(TAG, "settings %s", err == ESP_OK ? "saved" : "SAVE FAILED");
}

void settings_factory_reset(void)
{
    settings_t *c = lock_mut();
    *c = k_defaults;
    unlock_mut();
    settings_save();
    ESP_LOGW(TAG, "factory reset applied");
}

/* ---- numeric keys: explicit dispatcher - clear and type-checked ---- */

bool settings_set_num(const char *key, double value)
{
    if (!key || !isfinite(value)) return false;
    bool ok = false;
    settings_t *c = lock_mut();

    if      (!strcmp(key, "rssi1m"))  { if (value > -99 && value < 0)     { c->rssi_1m = (float)value; ok = true; } }
    else if (!strcmp(key, "pathn"))   { if (value >= 1.5 && value <= 4.5) { c->path_n  = (float)value; ok = true; } }
    else if (!strcmp(key, "antoff"))  { if (value >= 0 && value <= 180)   { c->ant_off_deg = (float)value; ok = true; } }
    else if (!strcmp(key, "range"))   { if (value >= 0.2 && value <= 5.0) { c->hold_m  = (float)value; ok = true; } }
    else if (!strcmp(key, "maxspd"))  { if (value >= 10 && value <= 100)  { c->max_speed_pct = (float)value; ok = true; } }
    else if (!strcmp(key, "minspd"))  { if (value >= 5 && value <= 60)    { c->min_speed_pct = (float)value; ok = true; } }
    else if (!strcmp(key, "turnpct")) { if (value >= 15 && value <= 100)  { c->turn_pct = (float)value; ok = true; } }
    else if (!strcmp(key, "turnms"))  { if (value >= 3 && value <= 30)    { c->turn_ms_per_deg = (float)value; ok = true; } }
    else if (!strcmp(key, "stopf"))   { if (value >= 8 && value <= 120)   { c->stop_front_cm = (float)value; ok = true; } }
    else if (!strcmp(key, "slowf"))   { if (value >= 20 && value <= 300)  { c->slow_front_cm = (float)value; ok = true; } }
    else if (!strcmp(key, "minduty")) { if (value >= 0 && value <= 60)    { c->minduty_pct = (float)value; ok = true; } }
    else if (!strcmp(key, "triml"))   { if (value >= 0.7 && value <= 1.3) { c->trim_l = (float)value; ok = true; } }
    else if (!strcmp(key, "trimr"))   { if (value >= 0.7 && value <= 1.3) { c->trim_r = (float)value; ok = true; } }
    else if (!strcmp(key, "invl"))    { c->invert_l = value ? 1 : 0; ok = true; }
    else if (!strcmp(key, "invr"))    { c->invert_r = value ? 1 : 0; ok = true; }
    else if (!strcmp(key, "unpair"))  { c->unpaired_follow = value ? 1 : 0; ok = true; }
    else if (!strcmp(key, "smin"))    { if (value >= 400 && value <= 1500) { c->servo_min_us = (uint16_t)value; ok = true; } }
    else if (!strcmp(key, "smax"))    { if (value >= 1500 && value <= 2600) { c->servo_max_us = (uint16_t)value; ok = true; } }
    else if (!strcmp(key, "dbg"))     { c->dbg = value ? 1 : 0; ok = true; }
    else if (!strcmp(key, "passkey")) { if (value >= 100000 && value <= 999999) { c->passkey = (uint32_t)value; ok = true; } }

    unlock_mut();
    if (!ok) ESP_LOGW(TAG, "rejected or unknown numeric key '%s'", key);
    return ok;
}

bool settings_set_str(const char *key, const char *value)
{
    if (!key || !value) return false;
    bool ok = false;
    settings_t *c = lock_mut();
    if (!strcmp(key, "name")) {
        size_t n = strlen(value);
        if (n >= 3 && n < SETTINGS_NAME_MAX) {
            memset(c->name, 0, SETTINGS_NAME_MAX);
            memcpy(c->name, value, n);
            ok = true;
        }
    }
    unlock_mut();
    return ok;
}

const char *settings_dump(char *buf, size_t cap)
{
    settings_t c;
    settings_get_copy(&c);
    snprintf(buf, cap,
        "name=%s passkey=%" PRIu32 " rssi1m=%.1f pathn=%.2f antoff=%.1f range=%.2f "
        "maxspd=%.0f minspd=%.0f turnpct=%.0f turnms=%.1f stopf=%.0f slowf=%.0f "
        "minduty=%.0f triml=%.3f trimr=%.3f invl=%u invr=%u unpair=%u smin=%u smax=%u dbg=%u",
        c.name, c.passkey, c.rssi_1m, c.path_n, c.ant_off_deg, c.hold_m,
        c.max_speed_pct, c.min_speed_pct, c.turn_pct, c.turn_ms_per_deg,
        c.stop_front_cm, c.slow_front_cm, c.minduty_pct, c.trim_l, c.trim_r,
        c.invert_l, c.invert_r, c.unpaired_follow, c.servo_min_us, c.servo_max_us, c.dbg);
    return buf;
}
