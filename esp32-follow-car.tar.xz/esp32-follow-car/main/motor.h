/*
 * motor.h - L298N dual H-bridge driver (left/right mixing inputs).
 *
 * Signed percentage targets (-100..100) per side; motor_tick() slews
 * duty toward the target (jerk limiting), applies the static-friction
 * duty floor, trim, and software direction inversion, and performs a
 * proper L298N brake (both inputs equal, EN high) when stopping.
 */
#pragma once

void  motor_init(void);
void  motor_set_lr(float l_pct, float r_pct);  /* signed targets */
void  motor_tick(void);                        /* call from 20 ms nav tick */
void  motor_get(float *l_pct, float *r_pct);   /* current effective values */
void  motor_brake_now(void);                   /* immediate brake sequence */
void  motor_kill(void);                        /* instant coast - watchdog path */
