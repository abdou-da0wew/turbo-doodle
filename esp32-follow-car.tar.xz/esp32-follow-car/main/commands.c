/*
 * commands.c - the complete command protocol.
 *
 *   HELP                          command list
 *   PING                          -> OK PONG
 *   VER                           firmware + IDF version
 *   STAT                          full one-line status
 *   MODE <IDLE|FOLLOW|MANUAL>     navigation mode
 *   ARM <ON|OFF>                  safety arming (FOLLOW only drives armed)
 *   M <F|B|L|R|S> [pct]           manual drive (MANUAL mode only)
 *   SERVO <0..180>                drive antenna servo directly
 *   TRN <±deg>                    calibration pivot in place
 *   TEST M <L%> <R%> <ms>         bounded motor bring-up test
 *   SET <key> <value>             change a setting (see GET ALL)
 *   GET <key|ALL>                 read settings
 *   CAL DIST <m>                  phone at known distance -> rssi1m
 *   CAL ANT                       current servo angle = straight ahead
 *   SAVE                          persist settings to NVS
 *   DEFAULTS                      factory reset settings
 *   UNBOND                        remove all BLE bonds
 *   UNPAIR                        forget learned phone address
 *
 * Every command answers "OK ..." or "E <n> <reason>".
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <math.h>
#include <stdarg.h>

#include "esp_log.h"
#include "esp_timer.h"
#include "esp_system.h"
#include "esp_idf_version.h"

#include "commands.h"
#include "settings.h"
#include "ble_link.h"
#include "nav.h"
#include "servo.h"
#include "sonar.h"
#include "motor.h"
#include "radar_math.h"

static const char *TAG = "cmd";

#define FW_VERSION "1.0.0"

static void reply(cmd_src_t src, const char *fmt, ...)
{
    char buf[128];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    if (src == CMD_SRC_BLE) {
        ble_link_send_rsp(buf);
    } else {
        printf("%s\n", buf);
    }
}

static int parse_float(const char *s, float *out)
{
    if (!s) return -1;
    char *end = NULL;
    float v = strtof(s, &end);
    if (end == s || !isfinite(v)) return -1;
    *out = v;
    return 0;
}

static void cmd_help(cmd_src_t src)
{
    reply(src, "OK HELP PING VER STAT MODE ARM M SERVO TRN TEST SET GET CAL SAVE DEFAULTS UNBOND UNPAIR");
}

static void cmd_stat(cmd_src_t src)
{
    link_snap_t L;
    ble_link_get_snap(&L);
    sonar_snap_t S;
    sonar_get(&S);
    float l = 0, r = 0;
    motor_get(&l, &r);
    float brg = 999.0f;
    int conf = 0;
    nav_tlm_bearing(&brg, &conf);

    reply(src,
          "OK st=%c mode=%s arm=%d conn=%d enc=%d adv=%d rssi=%d dist=%.2f "
          "brg=%.0f conf=%d f=%.0fcm r=%.0fcm ang=%.0f L=%d%% R=%d%% bonds=%d heap=%dkB",
          nav_state_char(),
          nav_mode() == NAV_MODE_FOLLOW ? "FOLLOW" : (nav_mode() == NAV_MODE_MANUAL ? "MANUAL" : "IDLE"),
          nav_armed() ? 1 : 0,
          L.connected ? 1 : 0, L.encrypted ? 1 : 0, L.advertising ? 1 : 0,
          L.connected ? L.rssi : (L.adv_valid ? L.adv_rssi : -100),
          nav_track_dist_m(),
          brg, conf, S.front_cm, S.rear_cm,
          servo_get_angle(), (int)l, (int)r, L.bond_num,
          (int)(esp_get_free_heap_size() / 1024));
}

static void cmd_mode(cmd_src_t src, const char *arg)
{
    if (!arg) { reply(src, "E 2 MODE needs IDLE|FOLLOW|MANUAL"); return; }
    if (!strcasecmp(arg, "IDLE") || !strcmp(arg, "0")) {
        nav_set_mode(NAV_MODE_IDLE);
        reply(src, "OK mode IDLE");
    } else if (!strcasecmp(arg, "FOLLOW") || !strcmp(arg, "1")) {
        nav_set_mode(NAV_MODE_FOLLOW);
        reply(src, "OK mode FOLLOW");
    } else if (!strcasecmp(arg, "MANUAL") || !strcmp(arg, "2")) {
        nav_set_mode(NAV_MODE_MANUAL);
        reply(src, "OK mode MANUAL");
    } else {
        reply(src, "E 2 bad mode");
    }
}

static void cmd_arm(cmd_src_t src, const char *arg)
{
    if (!arg) { reply(src, "E 2 ARM needs ON|OFF"); return; }
    if (!strcasecmp(arg, "ON") || !strcmp(arg, "1")) {
        nav_set_armed(true);
        reply(src, "OK armed");
    } else if (!strcasecmp(arg, "OFF") || !strcmp(arg, "0")) {
        nav_set_armed(false);
        reply(src, "OK disarmed");
    } else {
        reply(src, "E 2 bad arg");
    }
}

static void cmd_manual(cmd_src_t src, const char *d, const char *pct_s)
{
    if (nav_mode() != NAV_MODE_MANUAL) {
        reply(src, "E 3 enter MODE MANUAL first");
        return;
    }
    float pct = 40.0f;
    if (pct_s && parse_float(pct_s, &pct) != 0) {
        reply(src, "E 4 bad pct");
        return;
    }
    pct = rm_clampf(pct, 0.0f, 100.0f);
    if (!d) { reply(src, "E 2 M needs F|B|L|R|S"); return; }
    if (!strcasecmp(d, "F"))      nav_manual_lr(pct, pct);
    else if (!strcasecmp(d, "B")) nav_manual_lr(-pct, -pct);
    else if (!strcasecmp(d, "L")) nav_manual_lr(-pct, pct);
    else if (!strcasecmp(d, "R")) nav_manual_lr(pct, -pct);
    else if (!strcasecmp(d, "S")) nav_manual_lr(0, 0);
    else { reply(src, "E 2 bad dir"); return; }
    reply(src, "OK M %s %.0f", d, pct);
}

static void cmd_servo(cmd_src_t src, const char *arg)
{
    float deg;
    if (parse_float(arg, &deg) != 0 || deg < 0 || deg > 180) {
        reply(src, "E 4 SERVO needs 0..180");
        return;
    }
    nav_manual_servo(deg);
    reply(src, "OK servo %.0f", deg);
}

static void cmd_trn(cmd_src_t src, const char *arg)
{
    float deg;
    if (parse_float(arg, &deg) != 0 || deg < -180 || deg > 180) {
        reply(src, "E 4 TRN needs -180..180 (+ = right)");
        return;
    }
    nav_manual_turn(deg);
    reply(src, "OK pivot %.0f", deg);
}

static void cmd_test_motors(cmd_src_t src, const char *l, const char *r, const char *ms)
{
    if (nav_mode() == NAV_MODE_FOLLOW) {
        reply(src, "E 3 not while FOLLOW");
        return;
    }
    float pl, pr, ms_f;
    if (parse_float(l, &pl) || parse_float(r, &pr) || parse_float(ms, &ms_f)) {
        reply(src, "E 4 TEST M <L%%> <R%%> <ms>");
        return;
    }
    if (pl > 60 || pl < -60 || pr > 60 || pr < -60 || ms_f < 50 || ms_f > 2000) {
        reply(src, "E 4 range: pct -60..60, ms 50..2000");
        return;
    }
    nav_test_motors(pl, pr, (int)ms_f);
    reply(src, "OK test L=%.0f R=%.0f %dms", pl, pr, (int)ms_f);
}

static void cmd_cal_dist(cmd_src_t src, const char *arg)
{
    float d;
    if (parse_float(arg, &d) != 0 || d < 0.3f || d > 15.0f) {
        reply(src, "E 4 CAL DIST <0.3..15 meters>");
        return;
    }
    link_snap_t L;
    ble_link_get_snap(&L);
    int rssi = L.connected ? L.rssi : (L.adv_valid ? L.adv_rssi : 0);
    if (rssi == 0) {
        reply(src, "E 5 no RSSI yet (connect phone or see its adv)");
        return;
    }
    settings_t cfg;
    settings_get_copy(&cfg);
    float rssi1m = (float)rssi + 10.0f * cfg.path_n * log10f(d);
    settings_set_num("rssi1m", rssi1m);
    settings_save();
    reply(src, "OK rssi1m=%.1f (from rssi=%d at %.1fm) saved", rssi1m, rssi, d);
}

static void cmd_cal_ant(cmd_src_t src)
{
    float ang = servo_get_angle();
    settings_set_num("antoff", ang);
    settings_save();
    reply(src, "OK antoff=%.1f saved (point servo forward, then CAL ANT)", ang);
}

static void cmd_get(cmd_src_t src, const char *arg)
{
    char buf[320];
    if (!arg || !strcasecmp(arg, "ALL")) {
        settings_dump(buf, sizeof(buf));
        /* split into <=100 char chunks for BLE notify */
        size_t len = strlen(buf);
        if (src == CMD_SRC_BLE && len > 100) {
            char chunk[110];
            const char *p = buf;
            while (len > 0) {
                size_t n = len > 100 ? 100 : len;
                memcpy(chunk, p, n);
                chunk[n] = '\0';
                ble_link_send_rsp(chunk);
                p += n;
                len -= n;
            }
            return;
        }
        reply(src, "OK %s", buf);
        return;
    }
    settings_dump(buf, sizeof(buf));
    const char *p = strstr(buf, arg);
    if (!p || (p != buf && p[-1] != ' ')) {
        reply(src, "E 2 unknown key (GET ALL lists them)");
        return;
    }
    reply(src, "OK %s", p);
}

void commands_handle(const char *line, cmd_src_t src)
{
    char work[100];
    if (!line) return;
    size_t n = strlen(line);
    if (n == 0) return;
    if (n >= sizeof(work)) n = sizeof(work) - 1;
    memcpy(work, line, n);
    work[n] = '\0';

    /* trim */
    char *s = work;
    while (*s == ' ' || *s == '\t' || *s == '\r' || *s == '\n') s++;
    if (*s == '\0') return;

    char *save = NULL;
    char *cmd = strtok_r(s, " \t", &save);
    if (!cmd) return;

    char *a1 = strtok_r(NULL, " \t", &save);
    char *a2 = strtok_r(NULL, " \t", &save);
    char *a3 = strtok_r(NULL, " \t", &save);
    char *a4 = strtok_r(NULL, " \t", &save);

    ESP_LOGI(TAG, "[%s] %s %s %s %s %s", src == CMD_SRC_BLE ? "ble" : "uart",
             cmd, a1 ? a1 : "", a2 ? a2 : "", a3 ? a3 : "", a4 ? a4 : "");

    if (!strcasecmp(cmd, "HELP"))        cmd_help(src);
    else if (!strcasecmp(cmd, "PING"))   reply(src, "OK PONG");
    else if (!strcasecmp(cmd, "VER"))    reply(src, "OK follow-car v%s esp-idf %s", FW_VERSION, esp_get_idf_version());
    else if (!strcasecmp(cmd, "STAT"))   cmd_stat(src);
    else if (!strcasecmp(cmd, "MODE"))   cmd_mode(src, a1);
    else if (!strcasecmp(cmd, "ARM"))    cmd_arm(src, a1);
    else if (!strcasecmp(cmd, "M"))      cmd_manual(src, a1, a2);
    else if (!strcasecmp(cmd, "SERVO"))  cmd_servo(src, a1);
    else if (!strcasecmp(cmd, "TRN"))    cmd_trn(src, a1);
    else if (!strcasecmp(cmd, "TEST") && a1 && !strcasecmp(a1, "M")) cmd_test_motors(src, a2, a3, a4);
    else if (!strcasecmp(cmd, "TEST") && a1 && !strcasecmp(a1, "SONAR")) {
        sonar_snap_t S;
        sonar_get(&S);
        reply(src, "OK front=%.0fcm(fault=%d) rear=%.0fcm(fault=%d)",
              S.front_cm, S.front_fault, S.rear_cm, S.rear_fault);
    }
    else if (!strcasecmp(cmd, "SET")) {
        if (!a1 || !a2) { reply(src, "E 2 SET <key> <value>"); return; }
        char *end = NULL;
        double num = strtod(a2, &end);
        bool ok = (end && *end == '\0' && end != a2)
                    ? settings_set_num(a1, num)
                    : settings_set_str(a1, a2);
        if (ok) reply(src, "OK %s=%s (SAVE to persist)", a1, a2);
        else    reply(src, "E 2 rejected or unknown key");
    }
    else if (!strcasecmp(cmd, "GET"))    cmd_get(src, a1);
    else if (!strcasecmp(cmd, "CAL") && a1 && !strcasecmp(a1, "DIST")) cmd_cal_dist(src, a2);
    else if (!strcasecmp(cmd, "CAL") && a1 && !strcasecmp(a1, "ANT"))  cmd_cal_ant(src);
    else if (!strcasecmp(cmd, "SAVE"))   { settings_save(); reply(src, "OK saved"); }
    else if (!strcasecmp(cmd, "DEFAULTS")) { settings_factory_reset(); reply(src, "OK factory defaults restored"); }
    else if (!strcasecmp(cmd, "UNBOND")) ble_link_clear_bonds();
    else if (!strcasecmp(cmd, "UNPAIR")) { ble_link_clear_target(); reply(src, "OK target cleared"); }
    else reply(src, "E 1 unknown cmd (HELP)");
}
