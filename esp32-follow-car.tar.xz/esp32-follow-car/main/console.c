/*
 * console.c - command line over the USB serial port (UART0, 115200).
 *
 * Log output and command input share the port: type commands into any
 * serial monitor (idf.py monitor, screen, PuTTY). Every line is fed to
 * the same interpreter as BLE writes.
 */
#include <stdio.h>
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/uart.h"
#include "esp_log.h"

#include "console.h"
#include "commands.h"

static const char *TAG = "console";

#define CONSOLE_BAUD   115200
#define LINE_MAX       98

void console_task(void *pv)
{
    (void)pv;
    uart_config_t cfg = {
        .baud_rate  = CONSOLE_BAUD,
        .data_bits  = UART_DATA_8_BITS,
        .parity     = UART_PARITY_DISABLE,
        .stop_bits  = UART_STOP_BITS_1,
        .flow_ctrl  = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };
    ESP_ERROR_CHECK(uart_param_config(UART_NUM_0, &cfg));
    ESP_ERROR_CHECK(uart_driver_install(UART_NUM_0, 512, 0, 0, NULL, 0));

    ESP_LOGI(TAG, "console ready on UART0 @%d - type HELP", CONSOLE_BAUD);

    char line[LINE_MAX];
    int n = 0;
    while (1) {
        char ch;
        int got = uart_read_bytes(UART_NUM_0, &ch, 1, pdMS_TO_TICKS(20));
        if (got <= 0) continue;
        if (ch == '\r' || ch == '\n') {
            if (n > 0) {
                line[n] = '\0';
                commands_handle(line, CMD_SRC_UART);
                n = 0;
            }
        } else if (ch == 0x08 || ch == 0x7F) {           /* backspace */
            if (n > 0) n--;
        } else if (ch >= 0x20 && ch < 0x7F) {
            if (n < LINE_MAX - 1) line[n++] = ch;
        }
        if (n >= LINE_MAX - 1) {                          /* overflow guard */
            line[n] = '\0';
            commands_handle(line, CMD_SRC_UART);
            n = 0;
        }
    }
}
