/*
 * ui.c - onboard blue LED (GPIO2) status patterns + BOOT button (GPIO0).
 *
 * LED language:
 *   solid            : idle / manual mode (motors quiet)
 *   slow blink 1 Hz  : advertising, no phone
 *   double blink 1 Hz: connected, FOLLOW armed -> waiting for signal
 *   heartbeat 1 Hz   : connected and following
 *   triple flash /2 s: STOP_WAIT (searching / link lost)
 *   very fast blink  : fault (both sonars dead)
 *
 * Button gestures:
 *   short press      : IDLE -> FOLLOW(armed) | FOLLOW -> toggle armed
 *                      | MANUAL -> IDLE
 *   hold 5 s         : remove all BLE bonds (confirm: 3 fast flashes)
 */
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_log.h"

#include "ui.h"
#include "pins.h"
#include "nav.h"
#include "sonar.h"
#include "ble_link.h"

static const char *TAG = "ui";

static void led_set(bool on)
{
    gpio_set_level(PIN_LED, on ? 1 : 0);
}

static void led_init(void)
{
    gpio_config_t io = {
        .pin_bit_mask = (1ULL << PIN_LED),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    gpio_config(&io);
    led_set(true);
}

static void btn_init(void)
{
    gpio_config_t io = {
        .pin_bit_mask = (1ULL << PIN_BTN),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    gpio_config(&io);
}

static void short_action(void)
{
    switch (nav_mode()) {
    case NAV_MODE_IDLE:
        nav_set_mode(NAV_MODE_FOLLOW);
        nav_set_armed(true);
        ESP_LOGW(TAG, "btn: FOLLOW armed");
        break;
    case NAV_MODE_FOLLOW:
        nav_set_armed(!nav_armed());
        break;
    case NAV_MODE_MANUAL:
        nav_set_mode(NAV_MODE_IDLE);
        ESP_LOGW(TAG, "btn: back to IDLE");
        break;
    }
}

static void long_action(void)
{
    ESP_LOGW(TAG, "btn long: clearing all bonds");
    ble_link_clear_bonds();
    for (int i = 0; i < 6; i++) {       /* confirm flashes */
        led_set(i & 1);
        vTaskDelay(pdMS_TO_TICKS(60));
    }
}

void ui_task(void *pv)
{
    (void)pv;
    led_init();
    btn_init();
    ESP_LOGI(TAG, "ui task: LED GPIO%d, BOOT btn GPIO%d", PIN_LED, PIN_BTN);

    int tick = 0;
    bool led_state = true;

    /* button state */
    bool pressed = false, was_pressed = false;
    int press_ms = 0, stable = 0;
    bool long_fired = false;

    while (1) {
        vTaskDelay(pdMS_TO_TICKS(20));
        tick++;

        /* ---------- LED pattern ---------- */
        sonar_snap_t S;
        sonar_get(&S);
        link_snap_t L;
        ble_link_get_snap(&L);

        bool both_fault = S.front_fault && S.rear_fault;
        int period;
        bool on;
        char st = nav_state_char();

        if (both_fault) {
            period = 1;                                   /* 10 Hz */
            on = (tick / 5) & 1;
            led_set(on);
            led_state = on;
            goto button;
        }

        if (nav_mode() == NAV_MODE_MANUAL || st == 'I') {
            led_set(true); led_state = true; goto button;
        }

        if (st == 'E') {                                  /* stop wait */
            period = 100;                                 /* 2 s cycle */
            int ph = tick % period;
            on = (ph > 0 && ph <= 6) || (ph > 12 && ph <= 18) || (ph > 24 && ph <= 30);
            led_set(on); led_state = on; goto button;
        }

        if (L.connected) {
            if (st == 'W') {                              /* double blink */
                period = 50;
                int ph = tick % period;
                on = (ph > 0 && ph <= 8) || (ph > 12 && ph <= 20);
            } else {                                      /* heartbeat */
                period = 50;
                int ph = tick % period;
                on = (ph > 0 && ph <= 10);
            }
            led_set(on); led_state = on; goto button;
        }

        /* not connected: 1 Hz slow blink */
        on = (tick % 50) < 25;
        led_set(on); led_state = on;

button:
        /* ---------- BOOT button ---------- */
        bool level = gpio_get_level(PIN_BTN) == 0;        /* active low */
        if (level == was_pressed) {
            if (stable < 4) stable++;
        } else {
            stable = 0;
            was_pressed = level;
        }

        if (stable >= 4) {                                /* debounced */
            if (level && !pressed) {
                pressed = true;
                press_ms = 0;
                long_fired = false;
            } else if (level && pressed) {
                press_ms += 20;
                if (press_ms >= 5000 && !long_fired) {
                    long_fired = true;
                    long_action();
                }
            } else if (!level && pressed) {
                pressed = false;
                if (!long_fired && press_ms > 30 && press_ms < 800) {
                    short_action();
                }
            }
        }
    }
}
