/*
 * pins.h - Complete pin map for the BLE Follow-Car
 *
 * Target board: ESP32-S 30-pin DevKit (ESP-WROOM-32, CP2102)
 *
 * Peripherals:
 *  SG90 servo        : swings the whole ESP32 board (antenna radar aiming)
 *  L298N red board   : dual H-bridge, LEFT motors on OUT1/OUT2,
 *                      RIGHT motors on OUT3/OUT4 (4WD: pair in parallel)
 *  HC-SR04 #1 FRONT  : chassis-mounted, faces travel direction
 *  HC-SR04 #2 REAR   : chassis-mounted, faces backwards
 *  Onboard blue LED  : status patterns (GPIO2)
 *  BOOT button       : GPIO0, arm/disarm + clear-bonds gestures
 *
 * Wiring rules (see README):
 *  - HC-SR04 ECHO is 5 V TTL -> MUST go through a divider to ESP32:
 *        ECHO --[2.2k]--+--[3.3k]-- GND     + -> GPIO  (~3.0 V)
 *  - L298N logic inputs accept 3.3 V (VIH min 2.3 V per ST datasheet).
 *  - Remove ENA/ENB jumpers on the L298N board (we drive them with PWM).
 *  - All grounds common: battery -, L298N GND, ESP32 GND, servo GND.
 *  - Servo + ESP32 5 V from a dedicated 5 V buck (>=2 A), not from the
 *    L298N 5V regulator while motors stall (brownout risk).
 *  - Do NOT power the board over USB while mounted on the servo.
 */
#pragma once

/* ---- SG90 servo (LEDC TIMER_0 / CH_0, 50 Hz, 14-bit) ---- */
#define PIN_SERVO            GPIO_NUM_13

/* ---- Status LED (onboard blue) + BOOT button ---- */
#define PIN_LED              GPIO_NUM_2
#define PIN_BTN              GPIO_NUM_0   /* BOOT button */

/* ---- L298N red board ----
 * ENA/ENB = PWM enable (LEDC TIMER_1, 20 kHz, 10-bit, LOW_SPEED mode)
 * IN1..IN4 = plain GPIO direction pins                       */
#define PIN_MOTOR_ENA        GPIO_NUM_32  /* LEFT  side PWM  */
#define PIN_MOTOR_IN1        GPIO_NUM_18  /* LEFT  dir A     */
#define PIN_MOTOR_IN2        GPIO_NUM_19  /* LEFT  dir B     */
#define PIN_MOTOR_IN3        GPIO_NUM_21  /* RIGHT dir A     */
#define PIN_MOTOR_IN4        GPIO_NUM_22  /* RIGHT dir B     */
#define PIN_MOTOR_ENB        GPIO_NUM_33  /* RIGHT side PWM  */

/* ---- HC-SR04 ultrasonic sensors (RMT hardware-timed echo capture) ----
 * TRIG driven by RMT TX channel (12 us pulse, hard-timed)
 * ECHO captured by RMT RX channel (5 V -> ~3.0 V via resistor divider!) */
#define PIN_SONAR_F_TRIG     GPIO_NUM_23  /* front sensor trigger */
#define PIN_SONAR_F_ECHO     GPIO_NUM_34  /* front sensor echo (input-only, divider) */
#define PIN_SONAR_R_TRIG     GPIO_NUM_27  /* rear sensor trigger  */
#define PIN_SONAR_R_ECHO     GPIO_NUM_35  /* rear sensor echo (input-only, divider) */

/* ---- Pins intentionally left FREE for expansion ----
 * 4, 5, 12(strap), 14, 15, 16, 17, 25, 26, VP(36), VN(39)
 * NOTE: 16/17 are free on WROOM-32 boards (PSRAM only on WROVER).
 * GPIO12 is a strapping pin - leave unconnected or use as output only.
 */

/* ---- Shared LEDC setup ---- */
#define LEDC_SERVO_TIMER     LEDC_TIMER_0
#define LEDC_SERVO_CH        LEDC_CHANNEL_0
#define LEDC_SERVO_MODE      LEDC_LOW_SPEED_MODE
#define LEDC_SERVO_FREQ_HZ   50
#define LEDC_SERVO_RES       LEDC_TIMER_14_BIT          /* 16384 steps */

#define LEDC_MOTOR_TIMER     LEDC_TIMER_1
#define LEDC_MOTOR_CH_A      LEDC_CHANNEL_1
#define LEDC_MOTOR_CH_B      LEDC_CHANNEL_2
#define LEDC_MOTOR_MODE      LEDC_LOW_SPEED_MODE
#define LEDC_MOTOR_FREQ_HZ   20000                      /* above audible */
#define LEDC_MOTOR_RES       LEDC_TIMER_10_BIT          /* 0..1023 */
