/*
 * ui.h - status LED patterns + BOOT button gestures.
 */
#pragma once

void ui_task(void *pv);   /* pin to core 1 */
