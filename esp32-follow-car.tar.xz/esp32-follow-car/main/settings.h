/*
 * settings.h - NVS-persisted configuration for the follow-car.
 *
 * All tunables live in one versioned blob so a single NVS key covers
 * everything. Mutations go through settings_set_*() with range checks;
 * settings_save() commits to NVS. settings_factory_reset() restores
 * defaults.
 */
#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define SETTINGS_NAME_MAX 21

typedef struct {
    char     name[SETTINGS_NAME_MAX];  /* BLE advertise name            */
    uint32_t passkey;                  /* 6-digit pairing passkey       */

    float    rssi_1m;                  /* dBm reference at 1 m          */
    float    path_n;                   /* path-loss exponent            */
    float    ant_off_deg;              /* servo angle = antenna forward */

    float    hold_m;                   /* follow stop distance          */
    float    max_speed_pct;
    float    min_speed_pct;
    float    turn_pct;                 /* in-place pivot duty           */
    float    turn_ms_per_deg;          /* pivot rate calibration        */
    float    stop_front_cm;            /* hard stop / avoid threshold   */
    float    slow_front_cm;            /* start slowing down            */
    float    minduty_pct;              /* motor static-friction floor   */
    float    trim_l;                   /* 0.8..1.2 left side trim       */
    float    trim_r;
    uint8_t  invert_l;                 /* flip left motor wiring in SW  */
    uint8_t  invert_r;
    uint8_t  unpaired_follow;          /* also chase stored phone's adv */
    uint16_t servo_min_us;             /* SG90 pulse calibration        */
    uint16_t servo_max_us;
    uint8_t  dbg;                      /* verbose scan logging          */
} settings_t;

void        settings_init(void);
void        settings_get_copy(settings_t *out);

/* key names (strings): see commands.c SET/GET table */
bool        settings_set_str(const char *key, const char *value);
bool        settings_set_num(const char *key, double value);
const char *settings_dump(char *buf, size_t cap);   /* "k=v k=v ..."  */
void        settings_save(void);
void        settings_factory_reset(void);
