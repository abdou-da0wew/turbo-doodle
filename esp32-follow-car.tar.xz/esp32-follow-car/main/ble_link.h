/*
 * ble_link.h - BLE link layer: GATT server, pairing, phone tracking.
 *
 * Tracking model:
 *   - The phone (central) connects to the ESP32 GATT server. Pairing is
 *     LE Secure Connections + MITM + bonding with a static passkey.
 *   - While connected, the ESP32 polls the LINK RSSI (~10 Hz). Filtered
 *     RSSI -> path-loss model -> distance estimate.
 *   - The link RSSI is also what the radar sweep samples: the servo
 *     swings the whole board, RSSI peaks when the antenna points at the
 *     phone -> bearing. (A connected phone does not advertise, so link
 *     RSSI modulation is the only direction cue that needs no phone app.)
 *   - When NOT connected, the ESP32 scans for the last connected phone's
 *     address (learned automatically). If that device advertises (BT
 *     re-toggle, discoverable mode, etc.) its adv RSSI feeds the same
 *     distance model, enabling "chase mode" so the car drives towards
 *     the phone and the user can connect. iPhones use rotating private
 *     addresses, so this is best-effort by design.
 */
#pragma once
#include <stdbool.h>
#include <stdint.h>

typedef struct {
    bool    connected;
    bool    encrypted;
    bool    advertising;
    int     rssi;          /* filtered link RSSI, dBm             */
    bool    rssi_valid;
    int64_t rssi_ts_us;
    float   dist_m;        /* path-loss distance from link RSSI   */
    int     adv_rssi;      /* filtered adv RSSI of stored phone   */
    bool    adv_valid;
    int64_t adv_ts_us;
    float   adv_dist_m;
    int     bond_num;
} link_snap_t;

void ble_link_start(void);            /* non-blocking stack bring-up  */
void ble_link_task(void *pv);         /* pin to core 0                */
void ble_link_get_snap(link_snap_t *out);
void ble_link_send_rsp(const char *s);/* command response (BLE notify or log) */
void ble_link_clear_bonds(void);
void ble_link_clear_target(void);     /* forget learned phone address */
