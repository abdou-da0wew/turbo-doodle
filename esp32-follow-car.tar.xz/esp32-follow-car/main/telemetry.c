/*
 * telemetry.c - pulls a consistent snapshot from every module and packs
 * it into one compact CSV frame for BLE notify / serial status.
 */
#include <stdio.h>

#include "freertos/FreeRTOS.h"
#include "esp_system.h"

#include "telemetry.h"
#include "ble_link.h"
#include "nav.h"
#include "sonar.h"
#include "servo.h"
#include "motor.h"

void telemetry_build(char *buf, size_t cap)
{
    link_snap_t L;
    ble_link_get_snap(&L);
    sonar_snap_t S;
    sonar_get(&S);
    float l = 0, r = 0;
    motor_get(&l, &r);
    float brg = 999.0f;
    int conf = 0;
    nav_tlm_bearing(&brg, &conf);
    float dist = nav_track_dist_m();

    snprintf(buf, cap, "T,%c,%.2f,%d,%.0f,%d,%.0f,%.0f,%.0f,%d,%d,%d",
             nav_state_char(),
             dist,
             L.connected ? L.rssi : (L.adv_valid ? L.adv_rssi : -100),
             brg, conf,
             S.front_cm, S.rear_cm,
             servo_get_angle(),
             (int)l, (int)r,
             (int)(esp_get_free_heap_size() / 1024));
}
