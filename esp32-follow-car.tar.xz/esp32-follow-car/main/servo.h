/*
 * servo.h - SG90 servo driver (LEDC hardware PWM, slew-limited).
 *
 * The servo physically swings the whole ESP32 board so the PCB antenna
 * aims left/forward/right. Nav calls servo_tick() every 20 ms; the slew
 * limiter keeps motion smooth and within SG90 mechanics even when the
 * target jumps (e.g. park after a scan).
 */
#pragma once
#include <stdbool.h>

void  servo_init(void);
void  servo_set_target(float deg);   /* clamped 0..180, slew-limited */
void  servo_tick(void);              /* call from the 20 ms nav tick */
float servo_get_angle(void);         /* current mechanical angle     */
float servo_get_target(void);
