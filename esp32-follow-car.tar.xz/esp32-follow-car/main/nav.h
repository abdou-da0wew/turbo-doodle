/*
 * nav.h - follow-mode navigation: radar sweep -> bearing -> turn ->
 * drive bursts -> obstacle-aware speed mixing -> arrival hold.
 */
#pragma once
#include <stdbool.h>
#include <stdint.h>

typedef enum {
    NAV_MODE_IDLE = 0,
    NAV_MODE_FOLLOW,
    NAV_MODE_MANUAL,
} nav_mode_t;

void     nav_task(void *pv);            /* pin to core 1 */
void     nav_set_mode(nav_mode_t m);
nav_mode_t nav_mode(void);
void     nav_set_armed(bool on);
bool     nav_armed(void);

/* manual / calibration inputs (validated by commands.c) */
void     nav_manual_lr(float l_pct, float r_pct);   /* signed          */
void     nav_manual_turn(float deg);                /* +right, -left   */
void     nav_manual_servo(float deg);
void     nav_test_motors(float l_pct, float r_pct, int ms);

/* telemetry accessors */
char     nav_state_char(void);
float    nav_track_dist_m(void);        /* distance actually used, -1 */
void     nav_tlm_bearing(float *bearing_deg, int *conf);
uint32_t nav_last_tick_ms(void);        /* watchdog heartbeat */
