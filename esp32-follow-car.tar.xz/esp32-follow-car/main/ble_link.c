/*
 * ble_link.c - Bluedroid GAP + GATTS: advertising, scanning, secure
 * pairing (SC + MITM + bond, static passkey), command characteristic,
 * telemetry notify, link-RSSI polling, target-phone learning.
 */
#include <stdio.h>
#include <string.h>
#include <stdatomic.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "esp_bt.h"
#include "esp_bt_main.h"
#include "esp_gap_ble_api.h"
#include "esp_gatts_api.h"
#include "esp_gatt_common_api.h"
#include "esp_bt_device.h"
#include "nvs_flash.h"
#include "nvs.h"

#include "ble_link.h"
#include "settings.h"
#include "radar_math.h"
#include "telemetry.h"
#include "commands.h"

static const char *TAG = "ble";

/* ---------------- UUIDs ----------------
 * Base: f7a9xxxx-6b8d-4c3e-a2f1-5d4b9c8e7a10 (little-endian bytes) */
static const uint8_t UUID_SVC[16] = {
    0x10, 0x7a, 0x8e, 0x9c, 0x4b, 0x5d, 0xf1, 0xa2,
    0x3e, 0x4c, 0x8d, 0x6b, 0x01, 0x00, 0xa9, 0xf7 };
static const uint8_t UUID_CMD[16] = {
    0x10, 0x7a, 0x8e, 0x9c, 0x4b, 0x5d, 0xf1, 0xa2,
    0x3e, 0x4c, 0x8d, 0x6b, 0x02, 0x00, 0xa9, 0xf7 };
static const uint8_t UUID_TLM[16] = {
    0x10, 0x7a, 0x8e, 0x9c, 0x4b, 0x5d, 0xf1, 0xa2,
    0x3e, 0x4c, 0x8d, 0x6b, 0x03, 0x00, 0xa9, 0xf7 };
static const uint8_t UUID_RSP[16] = {
    0x10, 0x7a, 0x8e, 0x9c, 0x4b, 0x5d, 0xf1, 0xa2,
    0x3e, 0x4c, 0x8d, 0x6b, 0x04, 0x00, 0xa9, 0xf7 };

static const uint16_t UUID_PRI_SVC16  = 0x2800;
static const uint16_t UUID_CHAR_DECL  = 0x2803;
static const uint16_t UUID_CCC16      = 0x2902;

enum {
    IDX_SVC,
    IDX_CMD_DECL, IDX_CMD_VAL,
    IDX_TLM_DECL, IDX_TLM_VAL, IDX_TLM_CCC,
    IDX_RSP_DECL, IDX_RSP_VAL, IDX_RSP_CCC,
    IDX_NB
};

static uint8_t s_val_cmd[96];
static uint8_t s_val_tlm[96];
static uint8_t s_val_rsp[96];
static uint8_t s_decl_cmd[17];
static uint8_t s_decl_tlm[17];
static uint8_t s_decl_rsp[17];
static uint16_t s_ccc_tlm;
static uint16_t s_ccc_rsp;

static void decl_init(uint8_t *d, uint8_t prop, const uint8_t *uuid)
{
    d[0] = prop;
    memcpy(&d[1], uuid, 16);
}

#define ENC (ESP_GATT_PERM_READ_ENCRYPTED | ESP_GATT_PERM_WRITE_ENCRYPTED)

static const esp_gatts_attr_db_t gatt_db[IDX_NB] = {
    [IDX_SVC] = {
        .attr_control = { .auto_rsp = ESP_GATT_AUTO_RSP },
        .att_desc = { .uuid_length = ESP_UUID_LEN_16,
                       .uuid_p = (uint8_t *)&UUID_PRI_SVC16,
                       .perm = ESP_GATT_PERM_READ,
                       .max_length = 16, .length = 16,
                       .value = (uint8_t *)UUID_SVC },
    },
    [IDX_CMD_DECL] = {
        .attr_control = { .auto_rsp = ESP_GATT_AUTO_RSP },
        .att_desc = { .uuid_length = ESP_UUID_LEN_16,
                       .uuid_p = (uint8_t *)&UUID_CHAR_DECL,
                       .perm = ESP_GATT_PERM_READ,
                       .max_length = 17, .length = 17,
                       .value = s_decl_cmd },
    },
    [IDX_CMD_VAL] = {
        .attr_control = { .auto_rsp = ESP_GATT_AUTO_RSP },
        .att_desc = { .uuid_length = ESP_UUID_LEN_128,
                       .uuid_p = (uint8_t *)UUID_CMD,
                       .perm = ENC,
                       .max_length = sizeof(s_val_cmd), .length = 0,
                       .value = s_val_cmd },
    },
    [IDX_TLM_DECL] = {
        .attr_control = { .auto_rsp = ESP_GATT_AUTO_RSP },
        .att_desc = { .uuid_length = ESP_UUID_LEN_16,
                       .uuid_p = (uint8_t *)&UUID_CHAR_DECL,
                       .perm = ESP_GATT_PERM_READ,
                       .max_length = 17, .length = 17,
                       .value = s_decl_tlm },
    },
    [IDX_TLM_VAL] = {
        .attr_control = { .auto_rsp = ESP_GATT_AUTO_RSP },
        .att_desc = { .uuid_length = ESP_UUID_LEN_128,
                       .uuid_p = (uint8_t *)UUID_TLM,
                       .perm = ESP_GATT_PERM_READ_ENCRYPTED,
                       .max_length = sizeof(s_val_tlm), .length = 0,
                       .value = s_val_tlm },
    },
    [IDX_TLM_CCC] = {
        .attr_control = { .auto_rsp = ESP_GATT_AUTO_RSP },
        .att_desc = { .uuid_length = ESP_UUID_LEN_16,
                       .uuid_p = (uint8_t *)&UUID_CCC16,
                       .perm = ENC,
                       .max_length = 2, .length = 2,
                       .value = (uint8_t *)&s_ccc_tlm },
    },
    [IDX_RSP_DECL] = {
        .attr_control = { .auto_rsp = ESP_GATT_AUTO_RSP },
        .att_desc = { .uuid_length = ESP_UUID_LEN_16,
                       .uuid_p = (uint8_t *)&UUID_CHAR_DECL,
                       .perm = ESP_GATT_PERM_READ,
                       .max_length = 17, .length = 17,
                       .value = s_decl_rsp },
    },
    [IDX_RSP_VAL] = {
        .attr_control = { .auto_rsp = ESP_GATT_AUTO_RSP },
        .att_desc = { .uuid_length = ESP_UUID_LEN_128,
                       .uuid_p = (uint8_t *)UUID_RSP,
                       .perm = ESP_GATT_PERM_READ_ENCRYPTED,
                       .max_length = sizeof(s_val_rsp), .length = 0,
                       .value = s_val_rsp },
    },
    [IDX_RSP_CCC] = {
        .attr_control = { .auto_rsp = ESP_GATT_AUTO_RSP },
        .att_desc = { .uuid_length = ESP_UUID_LEN_16,
                       .uuid_p = (uint8_t *)&UUID_CCC16,
                       .perm = ENC,
                       .max_length = 2, .length = 2,
                       .value = (uint8_t *)&s_ccc_rsp },
    },
};

/* ---------------- advertising ---------------- */
static esp_ble_adv_params_t s_adv_params = {
    .adv_int_min        = 0x20,             /* 20 ms */
    .adv_int_max        = 0x40,             /* 40 ms */
    .adv_type           = ADV_TYPE_IND,
    .own_addr_type      = BLE_ADDR_TYPE_PUBLIC,
    .channel_map        = ADV_CHNL_ALL,
    .adv_filter_policy  = ADV_FILTER_ALLOW_SCAN_ANY_CON_ANY,
};

static esp_ble_adv_data_t s_adv_data = {
    .set_scan_rsp        = false,
    .include_name        = true,
    .include_txpower     = false,
    .min_interval        = 0x14,
    .max_interval        = 0x28,
    .appearance          = 0x00,
    .manufacturer_len    = 0,
    .p_manufacturer_data = NULL,
    .service_data_len    = 0,
    .p_service_data      = NULL,
    .service_uuid_len    = 0,
    .p_service_uuid      = NULL,
    .flag                = (ESP_BLE_ADV_FLAG_GEN_DISC | ESP_BLE_ADV_FLAG_BREDR_NOT_SPT),
};

static esp_ble_scan_params_t s_scan_params = {
    .scan_type          = BLE_SCAN_TYPE_ACTIVE,
    .own_addr_type      = BLE_ADDR_TYPE_PUBLIC,
    .scan_filter_policy = BLE_SCAN_FILTER_ALLOW_ALL,
    .scan_duplicate     = BLE_SCAN_DUPLICATE_DISABLE,  /* need fresh RSSI */
    .scan_interval      = 0x50,             /* 50 ms */
    .scan_window        = 0x30,             /* 30 ms */
};

/* ---------------- runtime state ---------------- */
static uint16_t s_gatts_if = ESP_GATT_IF_NONE;
static uint16_t s_h[IDX_NB];
static bool s_adv_data_done = false, s_scan_rsp_done = false;
static bool s_scan_desired = true;
static bool s_scanning = false;
static bool s_adv_active = false;

static volatile bool s_connected = false;
static volatile bool s_encrypted = false;
static volatile bool s_tlm_sub = false, s_rsp_sub = false;
static uint16_t s_conn_id = 0;
static esp_bd_addr_t s_conn_bda;
static char s_conn_bda_str[18] = "none";

static rm_rssi_filt_t s_link_filt;
static rm_rssi_filt_t s_adv_filt;

static portMUX_TYPE s_snap_mux = portMUX_INITIALIZER_UNLOCKED;
static link_snap_t s_snap;
static int64_t s_last_rssi_evt_us;
static int64_t s_last_adv_evt_us;

static esp_bd_addr_t s_target_bda;
static bool s_target_valid = false;


/* ---------------- helpers ---------------- */
static void addr_str(const uint8_t *bda, char *out, size_t cap)
{
    snprintf(out, cap, "%02X:%02X:%02X:%02X:%02X:%02X",
             bda[0], bda[1], bda[2], bda[3], bda[4], bda[5]);
}

/* scan response payload: complete 128-bit service UUID list (AD type 0x07) */
static uint8_t s_scan_rsp_raw[18] = {
    0x11, 0x07,
    0x10, 0x7a, 0x8e, 0x9c, 0x4b, 0x5d, 0xf1, 0xa2,
    0x3e, 0x4c, 0x8d, 0x6b, 0x01, 0x00, 0xa9, 0xf7,
};

static void publish_snap(void)
{
    settings_t cfg;
    settings_get_copy(&cfg);
    link_snap_t s;
    s.connected = s_connected;
    s.encrypted = s_encrypted;
    s.advertising = s_adv_active;
    s.rssi = (int)s_link_filt.ema;
    s.rssi_valid = s_link_filt.primed &&
                   (esp_timer_get_time() - s_last_rssi_evt_us) < 2000000;
    s.rssi_ts_us = s_last_rssi_evt_us;
    s.dist_m = s.rssi_valid ? rm_rssi_to_dist_m(s.rssi, cfg.rssi_1m, cfg.path_n) : -1.0f;
    s.adv_rssi = (int)s_adv_filt.ema;
    s.adv_valid = s_adv_filt.primed &&
                  (esp_timer_get_time() - s_last_adv_evt_us) < 4000000;
    s.adv_ts_us = s_last_adv_evt_us;
    s.adv_dist_m = s.adv_valid ? rm_rssi_to_dist_m(s.adv_rssi, cfg.rssi_1m, cfg.path_n) : -1.0f;
    s.bond_num = esp_ble_get_bond_device_num();

    portENTER_CRITICAL(&s_snap_mux);
    s_snap = s;
    portEXIT_CRITICAL(&s_snap_mux);
}

static void start_scan(void)
{
    if (s_connected || s_scanning) return;
    esp_err_t err = esp_ble_gap_start_scanning(0);   /* 0 = forever */
    if (err == ESP_OK) s_scanning = true;
    else ESP_LOGW(TAG, "start_scanning: %s", esp_err_to_name(err));
}

static void start_advertising(void)
{
    if (s_adv_active) return;
    esp_err_t err = esp_ble_gap_start_advertising(&s_adv_params);
    if (err != ESP_OK) ESP_LOGW(TAG, "start_advertising: %s", esp_err_to_name(err));
}

static void restart_gap_roles(void)
{
    start_advertising();
    if (s_scan_desired) start_scan();
}

/* ---------------- learned target (NVS) ---------------- */
static void target_load(void)
{
    nvs_handle_t h;
    if (nvs_open("fcar", NVS_READONLY, &h) == ESP_OK) {
        uint8_t buf[7];
        size_t len = sizeof(buf);
        if (nvs_get_blob(h, "tgtmac", buf, &len) == ESP_OK && len == 7 && buf[0] == 1) {
            memcpy(s_target_bda, buf + 1, 6);
            s_target_valid = true;
        }
        nvs_close(h);
    }
}

static void target_save(const uint8_t *bda)
{
    memcpy(s_target_bda, bda, 6);
    s_target_valid = true;
    nvs_handle_t h;
    if (nvs_open("fcar", NVS_READWRITE, &h) == ESP_OK) {
        uint8_t buf[7] = { 1 };
        memcpy(buf + 1, bda, 6);
        nvs_set_blob(h, "tgtmac", buf, sizeof(buf));
        nvs_commit(h);
        nvs_close(h);
    }
    ESP_LOGI(TAG, "target phone learned: %s", s_conn_bda_str);
}

void ble_link_clear_target(void)
{
    s_target_valid = false;
    memset(s_target_bda, 0, 6);
    nvs_handle_t h;
    if (nvs_open("fcar", NVS_READWRITE, &h) == ESP_OK) {
        nvs_erase_key(h, "tgtmac");
        nvs_commit(h);
        nvs_close(h);
    }
    ESP_LOGW(TAG, "target phone cleared");
}

/* ---------------- GAP events ---------------- */
static void gap_cb(esp_gap_ble_cb_event_t event, esp_ble_gap_cb_param_t *param)
{
    switch (event) {
    case ESP_GAP_BLE_ADV_DATA_SET_COMPLETE_EVT:
        s_adv_data_done = true;
        esp_ble_gap_config_scan_rsp_data_raw(s_scan_rsp_raw, sizeof(s_scan_rsp_raw));
        break;

    case ESP_GAP_BLE_SCAN_RSP_DATA_SET_COMPLETE_EVT:
        s_scan_rsp_done = true;
        restart_gap_roles();
        break;

    case ESP_GAP_BLE_ADV_START_COMPLETE_EVT:
        s_adv_active = (param->adv_start_cmpl.status == ESP_BT_STATUS_SUCCESS);
        if (!s_adv_active) {
            ESP_LOGW(TAG, "adv start failed 0x%x", param->adv_start_cmpl.status);
        }
        break;

    case ESP_GAP_BLE_ADV_STOP_COMPLETE_EVT:
        s_adv_active = false;
        break;

    case ESP_GAP_BLE_SCAN_PARAM_SET_COMPLETE_EVT:
        start_scan();
        break;

    case ESP_GAP_BLE_SCAN_START_COMPLETE_EVT:
        s_scanning = (param->scan_start_cmpl.status == ESP_BT_STATUS_SUCCESS);
        if (!s_scanning) {
            ESP_LOGW(TAG, "scan start failed 0x%x", param->scan_start_cmpl.status);
        }
        break;

    case ESP_GAP_BLE_SCAN_STOP_COMPLETE_EVT:
        s_scanning = false;
        break;

    case ESP_GAP_BLE_SCAN_RESULT_EVT: {
        if (param->scan_rst.search_evt != ESP_GAP_SEARCH_INQ_RES_EVT) break;
        if (!s_target_valid) break;
        if (memcmp(param->scan_rst.bda, s_target_bda, 6) != 0) break;

        /* stored phone is advertising: feed the adv filter (chase mode) */
        s_last_adv_evt_us = esp_timer_get_time();
        rm_rssi_filt_update(&s_adv_filt, param->scan_rst.rssi);
        break;
    }

    case ESP_GAP_BLE_READ_RSSI_COMPLETE_EVT: {
        if (param->read_rssi_cmpl.status != ESP_BT_STATUS_SUCCESS) {
            ESP_LOGW(TAG, "read_rssi status 0x%x", param->read_rssi_cmpl.status);
            break;
        }
        s_last_rssi_evt_us = esp_timer_get_time();
        rm_rssi_filt_update(&s_link_filt, param->read_rssi_cmpl.rssi);
        break;
    }

    case ESP_GAP_BLE_SEC_REQ_EVT:
        esp_ble_gap_security_rsp(param->ble_security.ble_req.bd_addr, true);
        break;

    case ESP_GAP_BLE_PASSKEY_NOTIF_EVT:
        ESP_LOGW(TAG, "*** PASSKEY: %06" PRIu32 " ***",
                 (uint32_t)param->ble_security.key_notif.passkey);
        break;

    case ESP_GAP_BLE_AUTH_CMPL_EVT: {
        bool ok = param->ble_security.auth_cmpl.success;
        s_encrypted = ok;
        char a[18];
        addr_str(param->ble_security.auth_cmpl.bd_addr, a, sizeof(a));
        if (ok) {
            ESP_LOGI(TAG, "paired+bonded with %s", a);
        } else {
            ESP_LOGE(TAG, "pairing FAILED with %s (reason 0x%x). "
                     "If this repeats: forget the device on the phone, or "
                     "send UNBOND / hold BOOT 5 s.", a,
                     param->ble_security.auth_cmpl.fail_reason);
        }
        break;
    }

    default:
        break;
    }
}

/* ---------------- GATTS events ---------------- */
static void gatts_cb(esp_gatts_cb_event_t event, esp_gatt_if_t gatts_if,
                     esp_ble_gatts_cb_param_t *param)
{
    switch (event) {
    case ESP_GATTS_REG_EVT:
        s_gatts_if = gatts_if;
        settings_t cfg;
        settings_get_copy(&cfg);

        uint32_t pk = cfg.passkey;
        uint8_t auth = ESP_LE_AUTH_REQ_SC_MITM_BOND;
        uint8_t iocap = ESP_IO_CAP_OUT;
        uint8_t maxkey = 16;
        esp_ble_gap_set_security_param(ESP_BLE_SM_AUTHEN_REQ_MODE, &auth, 1);
        esp_ble_gap_set_security_param(ESP_BLE_SM_IOCAP_MODE, &iocap, 1);
        esp_ble_gap_set_security_param(ESP_BLE_SM_SET_STATIC_PASSKEY, &pk, sizeof(pk));
        esp_ble_gap_set_security_param(ESP_BLE_SM_MAX_KEY_SIZE, &maxkey, 1);

        esp_ble_gap_set_device_name(cfg.name);
        esp_ble_gap_config_adv_data(&s_adv_data);
        esp_ble_gap_set_scan_params(&s_scan_params);

        decl_init(s_decl_cmd, ESP_GATT_CHAR_PROP_BIT_READ | ESP_GATT_CHAR_PROP_BIT_WRITE, UUID_CMD);
        decl_init(s_decl_tlm, ESP_GATT_CHAR_PROP_BIT_READ | ESP_GATT_CHAR_PROP_BIT_NOTIFY, UUID_TLM);
        decl_init(s_decl_rsp, ESP_GATT_CHAR_PROP_BIT_READ | ESP_GATT_CHAR_PROP_BIT_NOTIFY, UUID_RSP);

        esp_ble_gatts_create_attr_tab(gatt_db, gatts_if, IDX_NB, 0);
        break;

    case ESP_GATTS_CREAT_ATTR_TAB_EVT:
        if (param->add_attr_tab.status != ESP_GATT_OK ||
            param->add_attr_tab.num_handle != IDX_NB) {
            ESP_LOGE(TAG, "attr table create failed 0x%x n=%d",
                     param->add_attr_tab.status, param->add_attr_tab.num_handle);
            break;
        }
        memcpy(s_h, param->add_attr_tab.handles, sizeof(s_h));
        esp_ble_gatts_start_service(s_h[IDX_SVC]);
        ESP_LOGI(TAG, "GATT service started");
        break;

    case ESP_GATTS_START_EVT:
        restart_gap_roles();
        break;

    case ESP_GATTS_CONNECT_EVT: {
        s_conn_id = param->connect.conn_id;
        memcpy(s_conn_bda, param->connect.remote_bda, 6);
        addr_str(s_conn_bda, s_conn_bda_str, sizeof(s_conn_bda_str));
        s_connected = true;
        s_encrypted = false;
        s_tlm_sub = false;
        s_rsp_sub = false;
        rm_rssi_filt_reset(&s_link_filt);
        s_last_rssi_evt_us = esp_timer_get_time();
        ESP_LOGI(TAG, "phone connected: %s (conn_id=%u)", s_conn_bda_str, s_conn_id);

        target_save(s_conn_bda);
        s_scan_desired = false;
        if (s_scanning) esp_ble_gap_stop_scanning();

        /* trigger secure pairing immediately */
        esp_ble_set_encryption(s_conn_bda, ESP_BLE_SEC_ENCRYPT_MITM);

        /* fast connection parameters for responsive telemetry */
        esp_ble_conn_update_params_t cu = {
            .min_int = 24, .max_int = 40, .latency = 0, .timeout = 400,
        };
        memcpy(cu.bda, s_conn_bda, 6);
        esp_ble_gap_update_conn_params(&cu);
        break;
    }

    case ESP_GATTS_DISCONNECT_EVT:
        ESP_LOGW(TAG, "phone disconnected (reason 0x%x)",
                 param->disconnect.reason);
        s_connected = false;
        s_encrypted = false;
        s_tlm_sub = false;
        s_rsp_sub = false;
        s_connected = false;
        s_conn_id = 0;
        s_scan_desired = true;
        restart_gap_roles();
        break;

    case ESP_GATTS_WRITE_EVT: {
        uint16_t h = param->write.handle;
        if (h == s_h[IDX_CMD_VAL] && param->write.len > 0) {
            char cmd[97];
            int n = param->write.len;
            if (n > 96) n = 96;
            memcpy(cmd, param->write.value, n);
            cmd[n] = '\0';
            commands_handle(cmd, CMD_SRC_BLE);
        } else if (h == s_h[IDX_TLM_CCC] && param->write.len >= 2) {
            s_tlm_sub = (param->write.value[0] == 1);
        } else if (h == s_h[IDX_RSP_CCC] && param->write.len >= 2) {
            s_rsp_sub = (param->write.value[0] == 1);
        }
        break;
    }

    case ESP_GATTS_MTU_EVT:
        ESP_LOGI(TAG, "MTU=%d", param->mtu.mtu);
        break;

    default:
        break;
    }
}

/* ---------------- public API ---------------- */
void ble_link_start(void)
{
    memset(&s_snap, 0, sizeof(s_snap));
    rm_rssi_filt_reset(&s_link_filt);
    rm_rssi_filt_reset(&s_adv_filt);
    target_load();

    ESP_ERROR_CHECK(esp_bt_controller_mem_release(ESP_BT_MODE_CLASSIC_BT));

    esp_bt_controller_config_t bt_cfg = BT_CONTROLLER_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_bt_controller_init(&bt_cfg));
    ESP_ERROR_CHECK(esp_bt_controller_enable(ESP_BT_MODE_BLE));
    ESP_ERROR_CHECK(esp_bluedroid_init());
    ESP_ERROR_CHECK(esp_bluedroid_enable());
    ESP_ERROR_CHECK(esp_ble_gatt_set_local_mtu(220));

    ESP_ERROR_CHECK(esp_ble_gap_register_callback(gap_cb));
    ESP_ERROR_CHECK(esp_ble_gatts_register_callback(gatts_cb));
    ESP_ERROR_CHECK(esp_ble_gatts_app_register(0));

    ESP_LOGI(TAG, "BLE stack up: GATT server + scanner + advertiser");
}

void ble_link_get_snap(link_snap_t *out)
{
    portENTER_CRITICAL(&s_snap_mux);
    *out = s_snap;
    portEXIT_CRITICAL(&s_snap_mux);
}

void ble_link_send_rsp(const char *s)
{
    if (!s) return;
    if (s_connected && s_gatts_if != ESP_GATT_IF_NONE && s_h[IDX_RSP_VAL]) {
        int len = (int)strlen(s);
        if (len > 96) len = 96;
        esp_ble_gatts_set_attr_value(s_h[IDX_RSP_VAL], len, (const uint8_t *)s);
        if (s_rsp_sub) {
            esp_ble_gatts_send_indicate(s_gatts_if, s_conn_id, s_h[IDX_RSP_VAL],
                                        len, (uint8_t *)(uintptr_t)s, false);
        }
    } else {
        printf("[rsp] %s\n", s);
    }
}

void ble_link_clear_bonds(void)
{
    int num = esp_ble_get_bond_device_num();
    if (num <= 0) {
        ble_link_send_rsp("OK no bonds");
        return;
    }
    esp_ble_bond_dev_t list[10];
    if (num > 10) num = 10;
    if (esp_ble_get_bond_device_list(&num, list) == ESP_OK) {
        for (int i = 0; i < num; i++) {
            esp_ble_remove_bond_device(list[i].bd_addr);
        }
        char msg[32];
        snprintf(msg, sizeof(msg), "OK removed %d bond(s)", num);
        ble_link_send_rsp(msg);
    }
}

/* ---------------- link task (core 0) ---------------- */
void ble_link_task(void *pv)
{
    (void)pv;
    ESP_LOGI(TAG, "link task running: RSSI poll 10 Hz, telemetry 2 Hz");
    int tlm_div = 0;
    while (1) {
        vTaskDelay(pdMS_TO_TICKS(100));

        publish_snap();

        if (s_connected && s_gatts_if != ESP_GATT_IF_NONE) {
            /* poll connection RSSI; results arrive in gap_cb */
            esp_ble_gap_read_rssi(s_conn_bda);

            if (++tlm_div >= 5) {           /* 500 ms */
                tlm_div = 0;
                if (s_tlm_sub) {
                    char tlm[96];
                    telemetry_build(tlm, sizeof(tlm));
                    int len = (int)strlen(tlm);
                    esp_ble_gatts_set_attr_value(s_h[IDX_TLM_VAL], len, (const uint8_t *)tlm);
                    esp_ble_gatts_send_indicate(s_gatts_if, s_conn_id, s_h[IDX_TLM_VAL],
                                                len, (uint8_t *)tlm, false);
                }
            }
        }
    }
}
