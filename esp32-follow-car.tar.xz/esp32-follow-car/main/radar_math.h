/*
 * radar_math.h - Pure-C DSP helpers for the BLE radar tracker.
 *
 * No ESP-IDF dependencies: this file is compiled both into the firmware
 * and into the host-side unit tests (tools/host_test_radar.c).
 */
#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/* ---------- generic helpers ---------- */
float rm_clampf(float v, float lo, float hi);
float rm_median3f(float a, float b, float c);

/* ---------- RSSI filter ----------
 * Outlier-rejecting median-of-3 + EMA. Rejects single-sample spikes that
 * are >RM_OUTLIER_DB away from the current estimate, then passes the raw
 * value through a 3-tap median and a light EMA. */
#define RM_OUTLIER_DB 15.0f
#define RM_EMA_ALPHA  0.35f

typedef struct {
    float ema;
    float win[3];
    int   n;
    bool  primed;
} rm_rssi_filt_t;

void  rm_rssi_filt_reset(rm_rssi_filt_t *f);
float rm_rssi_filt_update(rm_rssi_filt_t *f, int raw_rssi);

/* ---------- log-distance path-loss model ----------
 * d = 10^((RSSI@1m - RSSI) / (10*n)). Returns clamped distance in meters,
 * or -1.0f for impossible RSSI values. */
float rm_rssi_to_dist_m(int rssi, float rssi_at_1m, float path_n);

/* ---------- bearing estimator (radar sweep) ----------
 * Input: RSSI samples taken at known servo angles during one antenna
 * sweep (0..180 deg). Output: bearing = servo angle whose direction has
 * the highest RSSI (power-weighted centroid around the peak), with a
 * confidence score based on peak prominence and sweep coverage.
 *
 * bearing_deg is in SERVO-ANGLE space (0..180). The caller converts it
 * to a vehicle-relative steering error by subtracting the calibrated
 * "antenna straight ahead" servo angle (ant_off_deg). */
#define RM_MIN_SWEEP_PTS   8
#define RM_PEAK_MIN_RSSI  (-92.0f)
#define RM_MIN_PROMINENCE 3.0f

typedef struct {
    float angle_deg;   /* servo angle of the sample, 0..180 */
    float rssi;        /* filtered RSSI at that angle       */
} rm_sweep_pt_t;

typedef struct {
    bool  valid;
    float bearing_deg;    /* servo-angle space */
    float peak_rssi;
    float prominence_db;
    int   conf;           /* 0..100 */
} rm_bearing_t;

void rm_solve_bearing(const rm_sweep_pt_t *pts, int n, rm_bearing_t *out);
