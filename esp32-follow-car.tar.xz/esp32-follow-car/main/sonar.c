/*
 * sonar.c - Dual HC-SR04 with RMT hardware timing (IDF 5.x new RMT API).
 *
 * Why RMT: the echo pulse is measured by dedicated hardware, so a
 * Bluetooth/WiFi interrupt storm on core 0 cannot stretch or shorten a
 * measurement. TRIG is also RMT-generated (a hard-timed 12 us pulse that
 * satisfies both the 10 us classic spec and the 5 us minimum of the
 * "RAM" module variant).
 *
 * Measurement chain per sensor:
 *   1. arm RMT RX (idle timeout 32 ms = "nothing in range")
 *   2. fire 12 us TRIG pulse via RMT TX
 *   3. recv_done callback: parse longest high run -> echo microseconds
 *   4. task converts to cm (us / 58), median-of-3 filters, updates snap
 *
 * No-echo handling: an echo that never arrives ends the RX transaction
 * at the idle timeout with zero symbols -> "open" (reported 400 cm).
 * A sensor that produces no valid echo for >1.5 s is flagged FAULTY so
 * the navigator can degrade speed instead of trusting a dead sensor.
 */
#include <stdatomic.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/rmt_tx.h"
#include "driver/rmt_rx.h"
#include "esp_log.h"
#include "esp_timer.h"

#include "sonar.h"
#include "pins.h"
#include "radar_math.h"

static const char *TAG = "sonar";

#define SONAR_RESOLUTION_HZ   1000000          /* 1 tick = 1 us */
#define SONAR_TIMEOUT_US      32000            /* RX idle timeout */
#define SONAR_TRIG_HIGH_US    12
#define SONAR_TRIG_LOW_US     200
#define ECHO_TO_CM(us)        ((float)(us) / 58.0f)
#define FAULT_AFTER_MS        1500
#define GAP_BETWEEN_PINGS_MS  12

typedef struct {
    rmt_channel_handle_t rx;
    rmt_encoder_handle_t enc;
    rmt_symbol_word_t    rx_buf[16];
    bool                 is_front;
    const char          *name;
} sonar_ch_t;

static rmt_channel_handle_t s_tx[2];
static sonar_ch_t s_ch[2];
static TaskHandle_t s_task;
static atomic_uint s_done_bits;          /* bit0 front, bit1 rear */
static atomic_int  s_raw_us[2];          /* 0 = no echo / timeout */

static portMUX_TYPE s_snap_mux = portMUX_INITIALIZER_UNLOCKED;
static sonar_snap_t s_snap;

/* ------------ echo parsing (runs in ISR context) ------------ */
static int parse_echo_us(const rmt_rx_done_event_data_t *e)
{
    if (!e || e->num_symbols == 0) return 0;
    int best = 0, acc = 0;
    for (size_t i = 0; i < e->num_symbols; i++) {
        const rmt_symbol_word_t *w = &e->received_symbols[i];
        if (w->level0 == 1) acc += (int)w->duration0;
        else { if (acc > best) best = acc; acc = 0; }
        if (w->level1 == 1) acc += (int)w->duration1;
        else { if (acc > best) best = acc; acc = 0; }
    }
    if (acc > best) best = acc;
    /* gate: <10 us is electrical noise, >30 ms exceeds sensor range */
    if (best < 10 || best > 30000) return 0;
    return best;
}

static bool rx_done_cb(rmt_channel_handle_t ch, const rmt_rx_done_event_data_t *e, void *u)
{
    (void)ch;
    sonar_ch_t *s = (sonar_ch_t *)u;
    int idx = s->is_front ? 0 : 1;
    atomic_store(&s_raw_us[idx], parse_echo_us(e));
    atomic_fetch_or(&s_done_bits, (unsigned)(1u << idx));
    BaseType_t hpw = pdFALSE;
    if (s_task) vTaskNotifyGiveFromISR(s_task, &hpw);
    return hpw == pdTRUE;
}

/* ------------ per-channel setup ------------ */
static void chan_init(sonar_ch_t *s, gpio_num_t trig, gpio_num_t echo,
                      bool is_front, const char *name)
{
    s->is_front = is_front;
    s->name = name;
    atomic_store(&s_raw_us[is_front ? 0 : 1], 0);

    rmt_tx_channel_config_t tx_cfg = {
        .gpio_num           = trig,
        .clk_src            = RMT_CLK_SRC_DEFAULT,
        .resolution_hz      = SONAR_RESOLUTION_HZ,
        .mem_block_symbols  = 64,
        .trans_queue_depth  = 1,
    };
    ESP_ERROR_CHECK(rmt_new_tx_channel(&tx_cfg, &s_tx[is_front ? 0 : 1]));
    ESP_ERROR_CHECK(rmt_enable(s_tx[is_front ? 0 : 1]));

    rmt_rx_channel_config_t rx_cfg = {
        .gpio_num           = echo,
        .clk_src            = RMT_CLK_SRC_DEFAULT,
        .resolution_hz      = SONAR_RESOLUTION_HZ,
        .mem_block_symbols  = 64,
    };
    ESP_ERROR_CHECK(rmt_new_rx_channel(&rx_cfg, &s->rx));
    ESP_ERROR_CHECK(rmt_enable(s->rx));

    rmt_rx_event_callbacks_t cbs = { .on_recv_done = rx_done_cb };
    ESP_ERROR_CHECK(rmt_rx_register_event_callbacks(s->rx, &cbs, s));

    rmt_copy_encoder_config_t enc_cfg = { };
    ESP_ERROR_CHECK(rmt_new_copy_encoder(&enc_cfg, &s->enc));

    ESP_LOGI(TAG, "%s: TRIG=GPIO%d (RMT TX) ECHO=GPIO%d (RMT RX)",
             name, trig, echo);
}

static void ping(sonar_ch_t *s)
{
    int idx = s->is_front ? 0 : 1;
    atomic_fetch_and(&s_done_bits, (unsigned)~(1u << idx));
    atomic_store(&s_raw_us[idx], -1);          /* pending */

    rmt_receive_config_t rcfg = {
        .signal_range_min_ns = 1000,           /* filter <1 us glitches */
        .signal_range_max_ns = SONAR_TIMEOUT_US * 1000,
    };
    /* arm RX first so the echo start edge can never be missed */
    esp_err_t err = rmt_receive(s->rx, s->rx_buf, sizeof(s->rx_buf), &rcfg);
    if (err != ESP_OK) {
        /* stale transaction: force-reset the channel and retry once */
        rmt_disable(s->rx);
        rmt_enable(s->rx);
        err = rmt_receive(s->rx, s->rx_buf, sizeof(s->rx_buf), &rcfg);
        if (err != ESP_OK) {
            ESP_LOGW(TAG, "%s re-arm failed %s", s->name, esp_err_to_name(err));
            atomic_store(&s_raw_us[idx], 0);
            atomic_fetch_or(&s_done_bits, (unsigned)(1u << idx));
            return;
        }
    }

    rmt_symbol_word_t trig = {
        .duration0 = SONAR_TRIG_HIGH_US, .level0 = 1,
        .duration1 = SONAR_TRIG_LOW_US,  .level1 = 0,
    };
    rmt_transmit_config_t tcfg = { .loop_count = 0 };
    ESP_ERROR_CHECK(rmt_transmit(s_tx[idx], s->enc, &trig, sizeof(trig), &tcfg));
}

/* ------------ filtering ------------ */
typedef struct {
    float win[3];
    int   n;
    int64_t last_valid_us;
    int   consec_open;
    bool  fault;
} filt_t;

static filt_t s_filt[2];

static float filt_update(int idx, int raw_us)
{
    filt_t *f = &s_filt[idx];
    int64_t now = esp_timer_get_time();

    if (raw_us <= 0) {
        f->consec_open++;
        /* open = nothing within ~4 m; keep reporting open distance but
         * flag the sensor dead if it has not echoed for a long time */
        if (!f->fault && f->last_valid_us != 0 &&
            (now - f->last_valid_us) > (int64_t)FAULT_AFTER_MS * 1000) {
            f->fault = true;
            ESP_LOGW(TAG, "%s sensor FAULT (no echo >%d ms)",
                     s_ch[idx].name, FAULT_AFTER_MS);
        }
        if (f->last_valid_us == 0 && f->consec_open > 20) {
            f->fault = true;   /* never produced a reading since boot */
            ESP_LOGW(TAG, "%s sensor FAULT (never echoed)", s_ch[idx].name);
        }
        return 400.0f;
    }

    f->consec_open = 0;
    f->last_valid_us = now;
    if (f->fault) {
        f->fault = false;
        ESP_LOGI(TAG, "%s sensor recovered", s_ch[idx].name);
    }

    f->win[f->n % 3] = (float)raw_us;
    f->n++;
    float med = (f->n < 3) ? (float)raw_us
                           : rm_median3f(f->win[0], f->win[1], f->win[2]);
    float cm = ECHO_TO_CM(med);
    if (cm < 2.0f) cm = 2.0f;
    if (cm > 450.0f) cm = 450.0f;
    return cm;
}

static void publish(int idx, float cm, bool fault)
{
    portENTER_CRITICAL(&s_snap_mux);
    if (idx == 0) {
        s_snap.front_cm = cm;
        s_snap.front_fault = fault;
        s_snap.front_ts_us = esp_timer_get_time();
    } else {
        s_snap.rear_cm = cm;
        s_snap.rear_fault = fault;
        s_snap.rear_ts_us = esp_timer_get_time();
    }
    portEXIT_CRITICAL(&s_snap_mux);
}

void sonar_init(void)
{
    memset(&s_snap, 0, sizeof(s_snap));
    s_snap.front_cm = s_snap.rear_cm = 400.0f;
    chan_init(&s_ch[0], PIN_SONAR_F_TRIG, PIN_SONAR_F_ECHO, true,  "front");
    chan_init(&s_ch[1], PIN_SONAR_R_TRIG, PIN_SONAR_R_ECHO, false, "rear");
}

static bool wait_done(int idx, int timeout_ms)
{
    unsigned bit = 1u << idx;
    int waited = 0;
    while (!(atomic_load(&s_done_bits) & bit)) {
        if (ulTaskNotifyTake(pdTRUE, pdMS_TO_TICKS(10)) == 0) {
            waited += 10;
            if (waited >= timeout_ms) return false;
            if (atomic_load(&s_done_bits) & bit) break;
        }
    }
    return true;
}

void sonar_task(void *pv)
{
    (void)pv;
    s_task = xTaskGetCurrentTaskHandle();
    ESP_LOGI(TAG, "sonar task running (hardware-timed RMT)");

    vTaskDelay(pdMS_TO_TICKS(200));

    while (1) {
        /* ---- front ping ---- */
        ping(&s_ch[0]);
        if (!wait_done(0, 120)) {
            atomic_store(&s_raw_us[0], 0);
        }
        int raw = atomic_load(&s_raw_us[0]);
        if (raw == -1) raw = 0;
        publish(0, filt_update(0, raw), s_filt[0].fault);

        vTaskDelay(pdMS_TO_TICKS(GAP_BETWEEN_PINGS_MS));

        /* ---- rear ping ---- */
        ping(&s_ch[1]);
        if (!wait_done(1, 120)) {
            atomic_store(&s_raw_us[1], 0);
        }
        raw = atomic_load(&s_raw_us[1]);
        if (raw == -1) raw = 0;
        publish(1, filt_update(1, raw), s_filt[1].fault);

        vTaskDelay(pdMS_TO_TICKS(GAP_BETWEEN_PINGS_MS));
    }
}

void sonar_get(sonar_snap_t *out)
{
    portENTER_CRITICAL(&s_snap_mux);
    *out = s_snap;
    portEXIT_CRITICAL(&s_snap_mux);
}
