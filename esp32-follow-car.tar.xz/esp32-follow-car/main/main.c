/*
 * main.c - BLE Follow-Car: boot sequence, task wiring, watchdog.
 *
 * Boot order:
 *   NVS -> settings -> LED/servo/motor/sonar -> BLE stack (async) ->
 *   tasks (core-pinned) -> banner.
 *
 * Core pinning (BT controller+host live on core 0 by sdkconfig):
 *   core 0 : ble_link_task, console_task, monitor_task
 *   core 1 : sonar_task, nav_task (control loop), ui_task
 * This keeps the 20 ms control loop and the RMT sonar timing isolated
 * from Bluetooth interrupts -> no BT timing conflicts, no sonar jitter.
 */
#include <stdio.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "nvs_flash.h"
#include "esp_log.h"
#include "esp_system.h"
#include "esp_timer.h"

#include "pins.h"
#include "settings.h"
#include "servo.h"
#include "motor.h"
#include "sonar.h"
#include "ble_link.h"
#include "nav.h"
#include "ui.h"
#include "console.h"
#include "telemetry.h"

static const char *TAG = "main";

static void monitor_task(void *pv)
{
    (void)pv;
    uint32_t last_seen = (uint32_t)(xTaskGetTickCount() * portTICK_PERIOD_MS);
    int div = 0;
    while (1) {
        vTaskDelay(pdMS_TO_TICKS(1000));
        uint32_t hb = nav_last_tick_ms();
        uint32_t delta = hb - last_seen;
        last_seen = hb;
        if (delta > 3000) {
            /* nav task stalled >=3 s: kill motors, hard fail-safe */
            motor_kill();
            ESP_LOGE(TAG, "WATCHDOG: nav task stalled %" PRIu32 " ms -> motors killed", delta);
        }
        if (++div >= 10) {
            div = 0;
            ESP_LOGI(TAG, "heap free=%" PRIu32 " kB min=%" PRIu32 " kB",
                     esp_get_free_heap_size() / 1024,
                     esp_get_minimum_free_heap_size() / 1024);
        }
    }
}

void app_main(void)
{
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);

    settings_init();

    ESP_LOGI(TAG, "=== ESP32 BLE Follow-Car ===");

    servo_init();
    motor_init();
    sonar_init();

    /* control-path tasks first (safety-ready even before BLE) */
    xTaskCreatePinnedToCore(sonar_task, "sonar",  3072, NULL, 5, NULL, 1);
    xTaskCreatePinnedToCore(nav_task,   "nav",    6144, NULL, 5, NULL, 1);
    xTaskCreatePinnedToCore(ui_task,    "ui",     2560, NULL, 3, NULL, 1);

    ble_link_start();
    xTaskCreatePinnedToCore(ble_link_task, "ble",  4096, NULL, 4, NULL, 0);
    xTaskCreatePinnedToCore(console_task, "cons",  4096, NULL, 2, NULL, 0);
    xTaskCreatePinnedToCore(monitor_task, "mon",   2560, NULL, 1, NULL, 0);

    settings_t cfg;
    settings_get_copy(&cfg);
    ESP_LOGI(TAG, "BLE name '%s' passkey %06" PRIu32, cfg.name, cfg.passkey);
    ESP_LOGI(TAG, "Wiring: servo=D13  L298N ENA=D32 IN1/2=D18/D19 IN3/4=D21/D22 ENB=D33");
    ESP_LOGI(TAG, "Sonars: FRONT trig=D23 echo=D34 | REAR trig=D27 echo=D35 (echo via 2.2k/3.3k divider)");
    ESP_LOGI(TAG, "Pair from nRF Connect / LightBlue; subscribe to Telemetry to enable notifies.");
    ESP_LOGI(TAG, "Serial: type HELP. Boot btn: short=arm/idle, hold 5s=clear bonds.");
    ESP_LOGI(TAG, "Follow distance %.2f m, max speed %.0f%%, antenna offset %.0f deg",
             cfg.hold_m, cfg.max_speed_pct, cfg.ant_off_deg);
}
