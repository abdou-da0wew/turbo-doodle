/*
 * servo.c - SG90 driver.
 *
 * LEDC 14-bit @ 50 Hz -> 1.22 us/step resolution (~0.8 deg), hardware
 * generated so there is zero jitter and zero CPU cost between frames.
 * Pulse range is configurable (settings smin/smax) because SG90 clones
 * vary: 600..2400 us covers most 180-degree units without stalling the
 * gearbox at the ends.
 */
#include <math.h>

#include "freertos/FreeRTOS.h"
#include "driver/ledc.h"
#include "esp_log.h"

#include "servo.h"
#include "pins.h"
#include "settings.h"
#include "radar_math.h"

static const char *TAG = "servo";

#define SERVO_SLEW_DEG_S   260.0f    /* well within SG90 no-load speed */
#define SERVO_TICK_MS      20
#define SERVO_PERIOD_US    20000

static float s_cur    = 90.0f;
static float s_target = 90.0f;
static uint16_t s_min_us = 600;
static uint16_t s_max_us = 2400;

static uint32_t angle_to_duty(float deg)
{
    float a = rm_clampf(deg, 0.0f, 180.0f);
    uint32_t pulse_us = s_min_us + (uint32_t)(((float)(s_max_us - s_min_us) * a) / 180.0f);
    uint32_t max_duty = (1u << LEDC_SERVO_RES) - 1;
    return (uint32_t)((uint64_t)pulse_us * max_duty / SERVO_PERIOD_US);
}

static void servo_write(float deg)
{
    ledc_set_duty(LEDC_SERVO_MODE, LEDC_SERVO_CH, angle_to_duty(deg));
    ledc_update_duty(LEDC_SERVO_MODE, LEDC_SERVO_CH);
}

void servo_init(void)
{
    settings_t cfg;
    settings_get_copy(&cfg);
    s_min_us = cfg.servo_min_us;
    s_max_us = cfg.servo_max_us;

    ledc_timer_config_t t = {
        .speed_mode      = LEDC_SERVO_MODE,
        .duty_resolution = LEDC_SERVO_RES,
        .timer_num       = LEDC_SERVO_TIMER,
        .freq_hz         = LEDC_SERVO_FREQ_HZ,
        .clk_cfg         = LEDC_AUTO_CLK,
    };
    ESP_ERROR_CHECK(ledc_timer_config(&t));

    ledc_channel_config_t c = {
        .gpio_num   = PIN_SERVO,
        .speed_mode = LEDC_SERVO_MODE,
        .channel    = LEDC_SERVO_CH,
        .intr_type  = LEDC_INTR_DISABLE,
        .timer_sel  = LEDC_SERVO_TIMER,
        .duty       = angle_to_duty(90.0f),
        .hpoint     = 0,
    };
    ESP_ERROR_CHECK(ledc_channel_config(&c));

    s_cur = 90.0f;
    s_target = 90.0f;
    ESP_LOGI(TAG, "SG90 on GPIO%d, %u..%u us (LEDC 14-bit @50 Hz)",
             PIN_SERVO, s_min_us, s_max_us);
}

void servo_set_target(float deg)
{
    s_target = rm_clampf(deg, 0.0f, 180.0f);
}

void servo_tick(void)
{
    float step = SERVO_SLEW_DEG_S * (SERVO_TICK_MS / 1000.0f);
    if (s_target > s_cur + step)       s_cur += step;
    else if (s_target < s_cur - step)  s_cur -= step;
    else                               s_cur = s_target;
    servo_write(s_cur);
}

float servo_get_angle(void)  { return s_cur; }
float servo_get_target(void) { return s_target; }
