/*
 * commands.h - text command interpreter, shared by BLE and UART console.
 */
#pragma once

typedef enum {
    CMD_SRC_BLE = 0,
    CMD_SRC_UART,
} cmd_src_t;

void commands_handle(const char *line, cmd_src_t src);
