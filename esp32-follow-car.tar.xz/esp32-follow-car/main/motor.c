/*
 * motor.c - L298N red-board driver.
 *
 * Per ST L298 datasheet, one bridge is controlled by IN1/IN2 + ENA:
 *   IN1=1 IN2=0 EN=1  -> forward        IN1=0 IN2=1 EN=1  -> reverse
 *   IN1=IN2 (any) EN=1 -> fast stop (brake, low-side recirculation)
 *   EN=0               -> free run (coast)
 * We PWM the EN pin (fast switching between drive and brake = duty
 * control) and set IN pins for direction. 3.3 V logic is a valid HIGH
 * (datasheet VIH min = 2.3 V).
 *
 * Speed mapping: requested 0..100% maps linearly onto the duty window
 * [minduty..100%] so small commands actually move the car instead of
 * stalling inside the L298N's ~2 V saturation drop + gearbox stiction.
 * PWM at 20 kHz (inaudible). Duty slew limits current spikes.
 */
#include <math.h>

#include "freertos/FreeRTOS.h"
#include "driver/ledc.h"
#include "driver/gpio.h"
#include "esp_log.h"

#include "motor.h"
#include "pins.h"
#include "settings.h"
#include "radar_math.h"

static const char *TAG = "motor";

#define MOTOR_TICK_MS        20
#define MOTOR_RAMP_PCT_S     260.0f   /* 0..100 % in ~0.4 s */
#define BRAKE_MS             130      /* active brake pulse on stop */
#define BRAKE_EXIT_PCT       3.0f     /* below this -> allow brake  */

typedef enum { MS_IDLE, MS_RAMP, MS_BRAKING } mstate_t;

static float s_tgt_l, s_tgt_r;      /* commanded (settings-applied later) */
static float s_cur_l, s_cur_r;      /* effective %                       */
static mstate_t s_state = MS_IDLE;
static int s_brake_until_ms = 0;

static int now_ms(void)
{
    return (int)(xTaskGetTickCount() * portTICK_PERIOD_MS);
}

static inline float apply_side(float pct, float trim, uint8_t invert)
{
    float v = rm_clampf(pct, -100.0f, 100.0f) * trim;
    return invert ? -v : v;
}

static void write_side(float pct, ledc_channel_t ch, gpio_num_t in1, gpio_num_t in2)
{
    settings_t cfg;
    settings_get_copy(&cfg);
    const uint32_t max_duty = (1u << LEDC_MOTOR_RES) - 1;
    uint32_t duty = 0;
    bool fwd;

    if (pct > 0.0f) {
        float floor = cfg.minduty_pct;
        duty = (uint32_t)(floor + (100.0f - floor) * (pct / 100.0f)) * max_duty / 100u;
        fwd = true;
    } else if (pct < 0.0f) {
        float a = -pct;
        float floor = cfg.minduty_pct;
        duty = (uint32_t)(floor + (100.0f - floor) * (a / 100.0f)) * max_duty / 100u;
        fwd = false;
    } else {
        duty = 0;
        fwd = true; /* don't care, EN will be 0 or brake */
    }

    if (duty == 0) {
        /* coast: EN low, inputs low */
        ledc_set_duty(LEDC_MOTOR_MODE, ch, 0);
        ledc_update_duty(LEDC_MOTOR_MODE, ch);
        gpio_set_level(in1, 0);
        gpio_set_level(in2, 0);
        return;
    }
    if (duty > max_duty) duty = max_duty;

    gpio_set_level(in1, fwd ? 1 : 0);
    gpio_set_level(in2, fwd ? 0 : 1);
    ledc_set_duty(LEDC_MOTOR_MODE, ch, duty);
    ledc_update_duty(LEDC_MOTOR_MODE, ch);
}

static void brake_outputs(void)
{
    /* both inputs equal + EN full = L298N fast motor stop */
    gpio_set_level(PIN_MOTOR_IN1, 1); gpio_set_level(PIN_MOTOR_IN2, 1);
    gpio_set_level(PIN_MOTOR_IN3, 1); gpio_set_level(PIN_MOTOR_IN4, 1);
    ledc_set_duty(LEDC_MOTOR_MODE, LEDC_MOTOR_CH_A, (1u << LEDC_MOTOR_RES) - 1);
    ledc_update_duty(LEDC_MOTOR_MODE, LEDC_MOTOR_CH_A);
    ledc_set_duty(LEDC_MOTOR_MODE, LEDC_MOTOR_CH_B, (1u << LEDC_MOTOR_RES) - 1);
    ledc_update_duty(LEDC_MOTOR_MODE, LEDC_MOTOR_CH_B);
}

static void coast_outputs(void)
{
    ledc_set_duty(LEDC_MOTOR_MODE, LEDC_MOTOR_CH_A, 0);
    ledc_update_duty(LEDC_MOTOR_MODE, LEDC_MOTOR_CH_A);
    ledc_set_duty(LEDC_MOTOR_MODE, LEDC_MOTOR_CH_B, 0);
    ledc_update_duty(LEDC_MOTOR_MODE, LEDC_MOTOR_CH_B);
    gpio_set_level(PIN_MOTOR_IN1, 0); gpio_set_level(PIN_MOTOR_IN2, 0);
    gpio_set_level(PIN_MOTOR_IN3, 0); gpio_set_level(PIN_MOTOR_IN4, 0);
}

void motor_init(void)
{
    ledc_timer_config_t t = {
        .speed_mode      = LEDC_MOTOR_MODE,
        .duty_resolution = LEDC_MOTOR_RES,
        .timer_num       = LEDC_MOTOR_TIMER,
        .freq_hz         = LEDC_MOTOR_FREQ_HZ,
        .clk_cfg         = LEDC_AUTO_CLK,
    };
    ESP_ERROR_CHECK(ledc_timer_config(&t));

    const gpio_num_t ch_pins[2] = { PIN_MOTOR_ENA, PIN_MOTOR_ENB };
    const ledc_channel_t chs[2] = { LEDC_MOTOR_CH_A, LEDC_MOTOR_CH_B };
    for (int i = 0; i < 2; i++) {
        ledc_channel_config_t c = {
            .gpio_num   = ch_pins[i],
            .speed_mode = LEDC_MOTOR_MODE,
            .channel    = chs[i],
            .intr_type  = LEDC_INTR_DISABLE,
            .timer_sel  = LEDC_MOTOR_TIMER,
            .duty       = 0,
            .hpoint     = 0,
        };
        ESP_ERROR_CHECK(ledc_channel_config(&c));
    }

    gpio_config_t io = {
        .pin_bit_mask = (1ULL << PIN_MOTOR_IN1) | (1ULL << PIN_MOTOR_IN2) |
                        (1ULL << PIN_MOTOR_IN3) | (1ULL << PIN_MOTOR_IN4),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    ESP_ERROR_CHECK(gpio_config(&io));

    coast_outputs();
    s_tgt_l = s_tgt_r = s_cur_l = s_cur_r = 0;
    ESP_LOGI(TAG, "L298N ready: ENA=%d IN1/2=%d/%d IN3/4=%d/%d ENB=%d, PWM %d Hz %d-bit",
             PIN_MOTOR_ENA, PIN_MOTOR_IN1, PIN_MOTOR_IN2, PIN_MOTOR_IN3, PIN_MOTOR_IN4,
             PIN_MOTOR_ENB, LEDC_MOTOR_FREQ_HZ, LEDC_MOTOR_RES);
}

void motor_set_lr(float l_pct, float r_pct)
{
    settings_t cfg;
    settings_get_copy(&cfg);
    s_tgt_l = apply_side(l_pct, cfg.trim_l, cfg.invert_l);
    s_tgt_r = apply_side(r_pct, cfg.trim_r, cfg.invert_r);
}

void motor_tick(void)
{
    const float step = MOTOR_RAMP_PCT_S * (MOTOR_TICK_MS / 1000.0f);

    if (s_state == MS_BRAKING) {
        if (now_ms() >= s_brake_until_ms) {
            coast_outputs();
            s_state = MS_IDLE;
        }
        return;
    }

    /* slew toward target */
    if (s_tgt_l > s_cur_l + step)      s_cur_l += step;
    else if (s_tgt_l < s_cur_l - step) s_cur_l -= step;
    else                               s_cur_l = s_tgt_l;

    if (s_tgt_r > s_cur_r + step)      s_cur_r += step;
    else if (s_tgt_r < s_cur_r - step) s_cur_r -= step;
    else                               s_cur_r = s_tgt_r;

    /* reached (near) zero with zero target -> brake instead of coasting */
    if (s_tgt_l == 0.0f && s_tgt_r == 0.0f) {
        if (fabsf(s_cur_l) < BRAKE_EXIT_PCT && fabsf(s_cur_r) < BRAKE_EXIT_PCT) {
            s_cur_l = s_cur_r = 0;
            brake_outputs();
            s_brake_until_ms = now_ms() + BRAKE_MS;
            s_state = MS_BRAKING;
            return;
        }
    }

    write_side(s_cur_l, LEDC_MOTOR_CH_A, PIN_MOTOR_IN1, PIN_MOTOR_IN2);
    write_side(s_cur_r, LEDC_MOTOR_CH_B, PIN_MOTOR_IN3, PIN_MOTOR_IN4);
}

void motor_get(float *l_pct, float *r_pct)
{
    if (l_pct) *l_pct = s_cur_l;
    if (r_pct) *r_pct = s_cur_r;
}

void motor_brake_now(void)
{
    s_tgt_l = s_tgt_r = s_cur_l = s_cur_r = 0;
    brake_outputs();
    s_brake_until_ms = now_ms() + BRAKE_MS;
    s_state = MS_BRAKING;
}

void motor_kill(void)
{
    s_tgt_l = s_tgt_r = s_cur_l = s_cur_r = 0;
    coast_outputs();
    s_state = MS_IDLE;
}
