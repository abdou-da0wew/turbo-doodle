/*
 * console.h - USB serial (UART0) command line input.
 */
#pragma once

void console_task(void *pv);   /* pin to core 0 */
