/*
 * host_test_radar.c - host-side unit tests for radar_math.c
 *
 * Build & run:
 *   gcc -O2 -Wall -Wextra -I main tools/host_test_radar.c main/radar_math.c -lm -o /tmp/host_test && /tmp/host_test
 */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "radar_math.h"

static int g_pass = 0, g_fail = 0;

#define CHECK(cond, name) do { \
    if (cond) { g_pass++; printf("  PASS  %s\n", name); } \
    else      { g_fail++; printf("  FAIL  %s\n", name); } \
} while (0)

static void test_clamp_median(void)
{
    printf("[clamp / median]\n");
    CHECK(rm_clampf(5, 0, 3) == 3.0f, "clamp high");
    CHECK(rm_clampf(-5, 0, 3) == 0.0f, "clamp low");
    CHECK(rm_median3f(9, 1, 5) == 5.0f, "median 9,1,5");
    CHECK(rm_median3f(1, 2, 3) == 2.0f, "median 1,2,3");
    CHECK(rm_median3f(7, 7, 2) == 7.0f, "median 7,7,2");
}

static void test_rssi_filter(void)
{
    printf("[rssi filter]\n");
    rm_rssi_filt_t f;
    rm_rssi_filt_reset(&f);

    rm_rssi_filt_update(&f, -60);
    rm_rssi_filt_update(&f, -62);
    float v = rm_rssi_filt_update(&f, -61);
    CHECK(fabsf(v - (-61.0f)) < 2.0f, "converges to mean of ~-61");

    /* single outlier must be rejected (15 dB gate) */
    float before = f.ema;
    float v2 = rm_rssi_filt_update(&f, -20);   /* +41 dB spike */
    CHECK(v2 == before, "spike rejected");
    CHECK(f.ema == before, "spike not absorbed");

    /* physically impossible values ignored */
    CHECK(rm_rssi_filt_update(&f, 5) == before, "positive rssi ignored");
    CHECK(rm_rssi_filt_update(&f, -130) == before, "below -100 ignored");

    /* slow drift is followed */
    for (int i = 0; i < 50; i++) rm_rssi_filt_update(&f, -70);
    CHECK(fabsf(f.ema - (-70.0f)) < 2.0f, "drift tracked to -70");
}

static void test_path_loss(void)
{
    printf("[path loss]\n");
    float d1 = rm_rssi_to_dist_m(-59, -59.0f, 2.6f);
    CHECK(fabsf(d1 - 1.0f) < 0.05f, "RSSI@1m -> 1.0 m");

    float d2 = rm_rssi_to_dist_m(-66, -59.0f, 2.6f);
    float expect = powf(10.0f, 7.0f / 26.0f);          /* ~1.86 m */
    CHECK(fabsf(d2 - expect) < 0.05f, "-7 dB -> ~1.86 m @ n=2.6");

    float d4 = rm_rssi_to_dist_m(-71, -59.0f, 2.6f);
    CHECK(d4 > d2, "monotonic: weaker rssi -> farther");

    CHECK(rm_rssi_to_dist_m(10, -59, 2.6f) == -1.0f, "invalid rssi -> -1");
    CHECK(rm_rssi_to_dist_m(-150, -59, 2.6f) == -1.0f, "impossible rssi -> -1");
}

/* synthetic sweep: RSSI bump centred at `true_angle` with gaussian-ish
 * shape + noise, elsewhere a flat floor. Verifies the estimator finds
 * the bearing and assigns decent confidence. */
static void test_bearing_at(float true_angle, float floor_db, float peak_db,
                            float noise_db, unsigned *seed, const char *name)
{
    rm_sweep_pt_t pts[40];
    int n = 0;
    for (int a = 0; a <= 180; a += 6) {
        float base = floor_db + (peak_db - floor_db) *
                     expf(-powf(a - true_angle, 2.0f) / (2.0f * 12.0f * 12.0f));
        /* xorshift noise +-noise_db */
        *seed ^= *seed << 13; *seed ^= *seed >> 17; *seed ^= *seed << 5;
        float nz = ((*seed % 1000) / 999.0f - 0.5f) * 2.0f * noise_db;
        pts[n].angle_deg = (float)a;
        pts[n].rssi = base + nz;
        n++;
    }
    rm_bearing_t r;
    rm_solve_bearing(pts, n, &r);
    char label[96];
    snprintf(label, sizeof(label), "%s: bearing %.1f (true %.0f) conf %d valid %d",
             name, r.valid ? r.bearing_deg : -1, true_angle, r.conf, r.valid);
    CHECK(r.valid && fabsf(r.bearing_deg - true_angle) < 8.0f && r.conf >= 40, label);
}

static void test_bearing(void)
{
    printf("[bearing estimator]\n");
    unsigned seed = 42;

    test_bearing_at(90, -70, -58, 2.0f, &seed, "center");
    test_bearing_at(30, -70, -58, 2.0f, &seed, "left");
    test_bearing_at(150, -70, -58, 2.0f, &seed, "right");
    test_bearing_at(60, -68, -60, 3.0f, &seed, "noisy 3dB");

    /* flat profile (no phone direction) -> must be invalid */
    rm_sweep_pt_t pts[40];
    int n = 0;
    for (int a = 0; a <= 180; a += 6) {
        pts[n].angle_deg = (float)a;
        pts[n].rssi = -65.0f + (float)(a % 3);
        n++;
    }
    rm_bearing_t r;
    rm_solve_bearing(pts, n, &r);
    CHECK(!r.valid, "flat sweep -> invalid");

    /* too few samples -> invalid */
    rm_solve_bearing(pts, 4, &r);
    CHECK(!r.valid, "too few samples -> invalid");

    /* peak buried in noise (0.8 dB prominence) -> invalid */
    n = 0;
    for (int a = 0; a <= 180; a += 6) {
        pts[n].angle_deg = (float)a;
        pts[n].rssi = -65.0f + 0.8f * expf(-powf(a - 120.0f, 2) / 100.0f);
        n++;
    }
    rm_solve_bearing(pts, n, &r);
    CHECK(!r.valid, "0.8 dB bump -> invalid (below prominence)");
}

static void test_pointing_offset(void)
{
    printf("[antenna offset mapping]\n");
    /* estimator returns SERVO-space bearing; nav subtracts ant_off.
     * With ant_off=90 and true phone at servo angle 60 -> err = -30 */
    unsigned seed = 7;
    rm_sweep_pt_t pts[40];
    int n = 0;
    for (int a = 0; a <= 180; a += 6) {
        float base = -70.0f + 12.0f * expf(-powf(a - 60.0f, 2.0f) / 288.0f);
        seed ^= seed << 13; seed ^= seed >> 17; seed ^= seed << 5;
        pts[n].angle_deg = (float)a;
        pts[n].rssi = base + (((int)(seed % 100)) - 50) * 0.04f;
        n++;
    }
    rm_bearing_t r;
    rm_solve_bearing(pts, n, &r);
    float ant_off = 90.0f;
    float err = r.valid ? (r.bearing_deg - ant_off) : 999.0f;
    CHECK(r.valid && fabsf(err - (-30.0f)) < 8.0f,
          "err ~= -30 (phone 30 deg to the left)");
}

int main(void)
{
    printf("=== radar_math host tests ===\n");
    test_clamp_median();
    test_rssi_filter();
    test_path_loss();
    test_bearing();
    test_pointing_offset();
    printf("=== %d passed, %d failed ===\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}
