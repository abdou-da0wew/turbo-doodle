# WHATS_DONE.md — Delivery and Progress Ledger

Companion to `WORKLOG.md` (the full narrative with reasoning). This file
is the cold, factual ledger: what is done, what is not, where everything
lives, the key facts you need at a glance, and the exact commands to
rebuild or re-provision anything.

**One-line status: the firmware is written, host-tested, compiled clean,
and packaged; what remains is physical assembly and bench bring-up, which
only hardware can do.**

---

## 1. Status at a glance

| Phase | Status | Evidence |
|---|---|---|
| Requirements contract | DONE | Original brief preserved in `upload/`; decomposed in `WORKLOG.md` Part A |
| Datasheet research | DONE | L298 (ST), HC-SR04 (SparkFun/UNL mirrors) read; facts table in `WORKLOG.md` Part B and README "Design facts" |
| Architecture design | DONE | Every decision + alternatives + reasons in `WORKLOG.md` Part C |
| Build environment (ESP-IDF v5.5.6) | DONE (this machine) | `/home/z/esp/` SDK + toolchain + python env; provisioning logs kept; playbook below |
| Firmware implementation | DONE | 12 modules + headers + pins.h, 3,463 lines of `main/` code, no stubs/TODOs |
| Host unit tests | DONE | `tools/host_test_radar.c`: **24/24 pass** |
| Compilation validation | DONE | `idf.py build` for esp32: **zero warnings**; `esp32_follow_car.bin` = 763,168 bytes (0xBA520) |
| Packaging | DONE | `download/esp32-follow-car/` (source-only) + `esp32-follow-car.tar.gz` (39,666 bytes) |
| User documentation | DONE | `README.md` (301 lines): wiring, power, bring-up, BLE, commands, tuning, troubleshooting |
| Flashing / on-robot bring-up | **NOT DONE** | No hardware exists in this sandbox — see §5 |
| Field calibration | **NOT DONE** | Requires the physical car + your phone (`CAL DIST`, `CAL ANT`, trims) |

---

## 2. What is done, itemized with evidence

1. **Complete firmware, zero stubs.** 12 modules under `main/`:
   `main.c` (boot, task wiring, watchdog), `nav.c` (follow state machine
   SCAN/TURN/DRIVE/HOLD/AVOID), `ble_link.c` (Bluedroid GATTS, LE Secure
   Connections + MITM + bonding, static passkey, 10 Hz link-RSSI polling,
   learned-target chase scan, telemetry notify), `commands.c` (BLE + UART
   shared text interpreter), `telemetry.c`, `settings.c` (NVS blob),
   `radar_math.c` (pure-C DSP, host-tested), `sonar.c` (dual HC-SR04 via
   RMT TX trigger / RX capture), `servo.c` (LEDC 50 Hz 14-bit,
   slew-limited), `motor.c` (L298N LEDC 20 kHz, ramp/brake/trim/minduty),
   `ui.c` (LED patterns + BOOT gestures), `console.c` (UART CLI).
   Verified by reading every file back from disk.
2. **Core pinning exactly as required.** Bluetooth stack pinned to core 0
   in sdkconfig (`BT_BLUEDROID_PINNED_TO_CORE=0`); `sonar`, `nav`, `ui`
   tasks pinned to core 1; `ble`, `cons`, `mon` to core 0 — verified in
   `main.c` + `sdkconfig.defaults`.
3. **Math proven before hardware.** `radar_math.c` compiles on the PC
   with zero IDF dependencies; 24 unit tests cover filters, spike
   rejection, path-loss monotonicity, bearing estimation (center / left /
   right / noisy / flat / insufficient) and antenna-offset mapping.
4. **Compile-verified.** Final `idf.py build` succeeded with zero
   warnings in application code; the binary and ELF are on disk in
   `esp32-follow-car/build/`.
5. **Environment fully provisioned on this machine.** ESP-IDF v5.5.6
   (commit `880a203ae603d08a94d06aa01e0d6761958e5e9e`), xtensa toolchain
   `esp-14.2.0_20260121`, python env 3.13.5, all under `/home/z/esp/`.
   The debugging trail (5 log files) is preserved there.
6. **User documentation shipped.** README includes the wiring tables, the
   power tree with the *why*, a 9-step bring-up checklist, pairing guide,
   full command reference, settings keys, telemetry format, safety
   model, LED language, and a troubleshooting table.
7. **This documentation set.** `WORKLOG.md` (narrative + reasoning),
   `WHATS_DONE.md` (this file), `worklog.md` (terse operational log).

## 3. Delivered files map

```
/home/z/my-project/
├── WORKLOG.md                          full narrative worklog
├── WHATS_DONE.md                       this ledger
├── worklog.md                          terse operational agent log
├── esp32-follow-car/                   working project (with build/ artifacts)
│   ├── CMakeLists.txt
│   ├── sdkconfig.defaults
│   ├── README.md                       the user manual
│   ├── main/                           12 modules + headers + pins.h
│   ├── tools/host_test_radar.c         24-test host suite
│   └── build/esp32_follow_car.bin|.elf compiled firmware
└── download/
    ├── esp32-follow-car/               clean source copy (no build artifacts)
    └── esp32-follow-car.tar.gz         packaged tarball
```

## 4. Key facts sheet (everything you need at a glance)

**Identity & security**
- BLE name: `ESP32-FollowCar` (settable via `SET name`)
- Pairing: LE Secure Connections + MITM + bonding; **static passkey `246810`**
- Service base UUID: `f7a90001-6b8d-4c3e-a2f1-5d4b9c8e7a10`;
  Command `…0002…` (write), Telemetry `…0003…` (read/notify),
  Response `…0004…` (read/notify) — encrypted
- First connected phone remembered as chase target (`UNPAIR` forgets)

**Pin map (30-pin DevKit)**

| Signal | GPIO | | Signal | GPIO |
|---|---|---|---|---|
| SG90 servo | D13 | | Sonar FRONT TRIG | D23 |
| Status LED | D2 | | Sonar FRONT ECHO | D34 (2.2k/3.3k divider) |
| BOOT button | D0 | | Sonar REAR TRIG | D27 |
| L298N ENA (left PWM) | D32 | | Sonar REAR ECHO | D35 (2.2k/3.3k divider) |
| L298N IN1 / IN2 | D18 / D19 | | L298N IN3 / IN4 | D21 / D22 |
| L298N ENB (right PWM) | D33 | | ENA/ENB jumpers | REMOVE |

**Hardware timings**
- Servo: 50 Hz, 14-bit LEDC (1.22 us/count), 600–2400 us default, `smin`/`smax` tunable
- Motors: 20 kHz, 10-bit LEDC; sweep: 6 deg steps / ~90 ms hold (~2.7 s full sweep)
- Sonar: 12 us trigger, ~12 Hz alternating per sensor, 32 ms no-echo timeout

**Telemetry frame (2 Hz notify)**
```
T,<state>,<dist_m>,<rssi>,<bearing>,<conf>,<front_cm>,<rear_cm>,<servo>,<L%>,<R%>,<heap_kb>
state: I idle | W wait-link | S scan | T turn | D drive | H hold | A avoid | M manual | X test | E stop-wait   (bearing 999 = invalid)
```

**Commands** (BLE or serial): `HELP PING VER STAT MODE ARM M SERVO TRN
TEST M/SONAR SET GET CAL DIST/CAL ANT SAVE DEFAULTS UNBOND UNPAIR`

**Settings keys**: `name passkey rssi1m pathn antoff range maxspd minspd
turnpct turnms stopf slowf minduty triml trimr invl invr unpair smin smax dbg`

## 5. What is NOT done (honest ledger)

1. **No hardware validation.** Nothing was ever flashed or powered: the
   sandbox has no ESP32, car, servo, or phone. "Works first try" is
   therefore guaranteed at the levels reachable from here — complete
   code, zero-warning build, unit-proven math, tree-verified APIs,
   documented failsafes — while physical bring-up follows the README's
   9-step checklist (wheels-up first).
2. **Field calibration is pending by nature.** `rssi_1m` (per-phone),
   `path_n` (per-room), `turnms` (per-chassis), `minduty`/trims
   (per-motors) all ship with sensible defaults and have explicit
   calibration commands; they get their true values on your bench.
3. **Chase mode is best-effort on iPhones** (rotating private BLE
   addresses). Best on Android, or immediately after a disconnect.

## 6. Quick start (from zero to following)

```bash
# Environment (already set up on this machine):
. /home/z/esp/esp-idf/export.sh          # sets IDF_PATH + PATH + python env

cd /home/z/my-project/esp32-follow-car   # or unpack the tarball anywhere
idf.py set-target esp32                  # only needed once per build dir
idf.py build                             # ~zero-warning build
idf.py -p /dev/ttyUSB0 flash monitor     # 115200 baud; Ctrl-] to exit
```

Then follow the README section "First-run bring-up" **in order**:
wheels-up boot check → `TEST SONAR` → `SERVO 0/90/180` → `TEST M 40 40 800`
(direction) → straightness trim → `TRN 90` pivot calibration →
`CAL DIST 1` / `CAL DIST 3` → `CAL ANT` → `MODE FOLLOW`.

Pairing: nRF Connect or LightBlue → connect to `ESP32-FollowCar` →
accept pairing → type `246810` → subscribe to Telemetry. Type `HELP`
over BLE or serial for the full command list.

Host unit tests any time (no hardware needed):
```bash
gcc -O2 -Wall -Wextra -I main tools/host_test_radar.c main/radar_math.c -lm -o /tmp/host_test && /tmp/host_test
# === 24 passed, 0 failed ===
```

## 7. Environment rebuild playbook (if the SDK is ever lost again)

This is the exact sequence that worked on this machine (Debian-family,
no root, python 3.12/3.13 mixed), distilled from the provisioning logs:

```bash
# 0) tools check (cmake/ninja were pip-installed here when missing)
python3 -m pip install --user cmake ninja virtualenv

# 1) clone the exact verified version (shallow, with submodules)
git clone --depth 1 --branch v5.5.6 --recursive --shallow-submodules \
  https://github.com/espressif/esp-idf.git $HOME/esp/esp-idf

# 2) install toolchains (fast; binaries come from github release assets)
export IDF_TOOLS_PATH=$HOME/esp/tools
cd $HOME/esp/esp-idf
./install.sh esp32        # python-env step may fail on venv/ensurepip boxes — that's OK

# 3) python env the way that works without ensurepip (the fix from the logs)
python3 -m virtualenv -p python3 $HOME/esp/tools/python_env/idf5.5_py3.13_env
. $HOME/esp/tools/python_env/idf5.5_py3.13_env/bin/activate
pip install -r $HOME/esp/esp-idf/tools/requirements.core.txt \
             --constraint $HOME/esp/esp-idf/tools/espidf.constraints.v5.5.txt
#    (the constraints file also downloads from dl.espressif.com — reachable
#     on this network; if ever blocked, use IDF_PYTHON_CHECK_CONSTRAINTS=no
#     or fetch it from raw.githubusercontent.com and point PIP_CONSTRAINT at it)
deactivate

# 4) use it
. $HOME/esp/esp-idf/export.sh
```

Notes learned the hard way (full stories in `WORKLOG.md` Part D):
- Run `install.sh` from a shell **not** inside a virtualenv, or it aborts
  with "can not create a virtual environment again".
- There is no `--no-constraints` flag; do not improvise installer flags.
- `python3 -m venv` fails on Debian-family boxes without the venv
  packaging bits and no root — `virtualenv` bundles its own pip and
  sidesteps ensurepip entirely.

## 8. Verification checklist (what was re-verified today, 2026-10-27)

- [x] Project tree intact: 12 modules + headers + pins.h present (3,463 lines in `main/`)
- [x] `build/esp32_follow_car.bin` (763,168 bytes) and `.elf` present from the successful build
- [x] ESP-IDF v5.5.6 present (`/home/z/esp/esp-idf`, commit `880a203ae603…`)
- [x] Toolchain `xtensa-esp-elf esp-14.2.0_20260121` + python env (3.13.5) present
- [x] Constraints file present (`/home/z/esp/tools/espidf.constraints.v5.5.txt`)
- [x] Package identical to source minus build artifacts (verified by diff)
- [x] Tarball present (39,666 bytes, `download/esp32-follow-car.tar.gz`)
- [x] Network allow-list healthy for rebuilds (github.com 200, pypi 200, dl.espressif.com 200)
- [ ] Flash + on-robot bring-up — **awaits hardware (yours)**

## 9. Document history

| Date | Change |
|---|---|
| 2026-10-27 (earlier) | Firmware written, tested, built, packaged on this machine; terse `worklog.md` created |
| 2026-10-27 (now) | `WORKLOG.md` + `WHATS_DONE.md` written from verified on-disk evidence (Task DOC-1) |

